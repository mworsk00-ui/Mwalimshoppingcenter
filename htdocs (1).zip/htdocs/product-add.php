<?php
$page_title = 'Add Product';
require_once __DIR__ . '/config/db.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['product_name'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $qty = trim($_POST['stock_qty'] ?? '');
    if ($name !== '') {
        try {
            $stmt = $pdo->prepare("INSERT INTO products (product_name, price, stock_qty) VALUES (?,?,?)");
            $stmt->execute([$name, $price, $qty]);
            header('Location: products.php');
            exit;
        } catch (Exception $e) { $msg = $e->getMessage(); }
    }
}
require_once __DIR__ . '/includes/header.php';
?>
<header class="leo-page-header">
    <div class="leo-page-header-left">
        <a href="products.php" class="leo-back-btn"><i class="fas fa-chevron-left"></i></a>
        <span class="leo-page-header-title">Add Product</span>
    </div>
    <div class="leo-page-header-actions">
        <button type="submit" form="productForm" class="leo-save-btn">SAVE</button>
    </div>
</header>

<form method="post" id="productForm" class="leo-form-card" style="margin:0.85rem;">
    <div class="leo-form-card-body">
        <?php if ($msg): ?><div style="color:#DC2626;font-size:0.82rem;margin-bottom:0.75rem;"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

        <div class="leo-form-row">
            <label class="leo-input-label">Product Name</label>
            <input type="text" name="product_name" class="leo-input" placeholder="Enter product name" required>
        </div>

        <div class="leo-form-row leo-form-row-inline">
            <div>
                <label class="leo-input-label">Price (TSH)</label>
                <input type="number" name="price" class="leo-input" placeholder="0" step="0.01" required>
            </div>
            <div>
                <label class="leo-input-label">Stock Quantity</label>
                <input type="text" name="stock_qty" class="leo-input"
                       placeholder="Select or type..."
                       list="stockQtyOptions" autocomplete="off" required>
                <datalist id="stockQtyOptions">
                    <!-- Most popular first -->
                    <option value="Piece (pc)">Piece (pc)</option>
                    <option value="Kilogram (kg)">Kilogram (kg)</option>
                    <option value="Gram (g)">Gram (g)</option>
                    <option value="Litre (L)">Litre (L)</option>
                    <option value="Millilitre (ml)">Millilitre (ml)</option>
                    <option value="Metre (m)">Metre (m)</option>
                    <option value="Centimetre (cm)">Centimetre (cm)</option>
                    <option value="Millimetre (mm)">Millimetre (mm)</option>
                    <option value="Box">Box</option>
                    <option value="Pack">Pack</option>
                    <option value="Carton">Carton</option>
                    <option value="Dozen">Dozen</option>
                    <option value="Bag">Bag</option>
                    <option value="Sack">Sack</option>
                    <option value="Bottle">Bottle</option>
                    <option value="Tin">Tin</option>
                    <option value="Roll">Roll</option>
                    <option value="Bundle">Bundle</option>
                    <option value="Set">Set</option>
                    <option value="Pair">Pair</option>
                    <option value="Tonne (t)">Tonne (t)</option>
                    <option value="Litre Tin (lta)">Litre Tin (lta)</option>
                    <option value="Goko (gk)">Goko (gk)</option>
                </datalist>
            </div>
        </div>

        <div class="leo-form-row">
            <label class="leo-input-label">Category (optional)</label>
            <select class="leo-input">
                <option>Select category</option>
                <option>Electronics</option>
                <option>Food &amp; Beverages</option>
                <option>Clothing &amp; Apparel</option>
                <option>Home &amp; Kitchen</option>
                <option>Health &amp; Beauty</option>
                <option>Stationery &amp; Office</option>
                <option>Hardware &amp; Tools</option>
                <option>Building Materials</option>
                <option>Agriculture</option>
                <option>Pharmaceuticals</option>
                <option>Baby &amp; Kids</option>
                <option>Sports &amp; Outdoors</option>
                <option>Automotive</option>
                <option>Pet Supplies</option>
                <option>Furniture</option>
                <option>Jewellery &amp; Watches</option>
                <option>Bags &amp; Luggage</option>
                <option>Toys &amp; Games</option>
                <option>Cleaning Supplies</option>
                <option>Other</option>
            </select>
        </div>
    </div>
</form>

<div class="leo-bottom-actions">
    <a href="products.php" class="leo-btn leo-btn--outline">CANCEL</a>
    <button type="submit" form="productForm" class="leo-btn leo-btn--primary">SAVE</button>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>