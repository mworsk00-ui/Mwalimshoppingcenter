<?php
/**
 * includes/header.php
 * Green theme — Mwalim Shop
 * Includes global auth guard + top header + drawer sidebar.
 */

/* ---------------------------------------------------------------
   1) SESSION
   --------------------------------------------------------------- */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ---------------------------------------------------------------
   2) AUTH GUARD — runs on EVERY page that loads this header
   --------------------------------------------------------------- */
if (empty($_SESSION['user_id'])) {

    /* Page basename so we can whitelist public pages */
    $__hdr_current = basename($_SERVER['PHP_SELF'] ?? '');

    /* Pages that may render WITHOUT being logged in */
    $__hdr_public = ['login.php', 'logout.php'];

    if (!in_array($__hdr_current, $__hdr_public, true)) {

        /* Remember where the user wanted to go */
        if (empty($_SESSION['redirect_after_login'])) {
            $req = $_SERVER['REQUEST_URI'] ?? '';
            if ($req !== '' && strpos($req, 'login.php') === false) {
                $_SESSION['redirect_after_login'] = $req;
            }
        }

        /* Bounce to login */
        header('Location: login.php');
        exit;
    }
}

/* ---------------------------------------------------------------
   3) PAGE VARIABLES
   --------------------------------------------------------------- */
$page_title = $page_title ?? 'Dashboard';
$user_name  = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Mwalimu';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#16A34A">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="Mwalim Shop">
    <title><?php echo htmlspecialchars($page_title); ?> | Mwalim Shop</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/leo-style.css">
</head>
<body>

<!-- SPLASH SCREEN -->
<div class="leo-splash" id="leoSplash">
    <div class="leo-splash-icon"><i class="fas fa-store"></i></div>
    <h1>Mwalim Shop</h1>
    <p>Business Management</p>
</div>

<!-- SIDEBAR DRAWER (green, slides in from left) -->
<?php require_once __DIR__ . '/sidebar.php'; ?>

<!-- APP HEADER (green) -->
<header class="leo-app-header">
    <div class="leo-app-header-left">
        <button class="leo-hamburger" onclick="openDrawer()" aria-label="Menu">
            <i class="fas fa-bars"></i>
        </button>
        <div class="leo-app-avatar"><i class="fas fa-user"></i></div>
        <div class="leo-app-name"><?php echo htmlspecialchars($user_name); ?></div>
    </div>
    <div class="leo-app-header-right">
        <button class="leo-header-icon" onclick="location.reload()" aria-label="Refresh">
            <i class="fas fa-sync-alt"></i>
        </button>
        <button class="leo-header-icon" aria-label="Notifications">
            <i class="fas fa-bell"></i>
        </button>
        <button class="leo-header-icon" aria-label="Language">
            <i class="fas fa-language"></i>
        </button>
        <button class="leo-header-icon" onclick="if(confirm('Logout?'))window.location.href='logout.php'" aria-label="Logout">
            <i class="fas fa-sign-out-alt"></i>
        </button>
    </div>
</header>

<main class="leo-app-content">