<?php
/**
 * includes/sidebar.php
 * Green drawer navigation — self-contained (inline CSS + JS).
 * Included ONLY from includes/header.php.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$__user = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Mwalimu';
$__role = $_SESSION['role'] ?? 'Admin';
$__cur  = basename($_SERVER['PHP_SELF'] ?? '');

if (!function_exists('drawer_active')) {
    function drawer_active($files, $current) {
        foreach ((array)$files as $f) {
            if ($f === $current) return 'active';
        }
        return '';
    }
}
?>

<!-- ============================================================
     DRAWER SIDEBAR — GREEN THEME (self-contained styling)
     ============================================================ -->
<style id="leo-drawer-styles">
    /* Backdrop */
    .leo-drawer-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(15, 23, 42, 0.55);
        backdrop-filter: blur(2px);
        opacity: 0;
        visibility: hidden;
        transition: opacity .25s ease, visibility .25s ease;
        z-index: 9998;
    }
    .leo-drawer-backdrop.show {
        opacity: 1;
        visibility: visible;
    }

    /* Drawer panel */
    .leo-drawer {
        position: fixed;
        top: 0;
        left: 0;
        width: 320px;
        max-width: 88vw;
        height: 100vh;
        background: linear-gradient(180deg, #16A34A 0%, #15803D 100%);
        color: #ffffff;
        transform: translateX(-100%);
        transition: transform .3s cubic-bezier(.4, 0, .2, 1);
        z-index: 9999;
        display: flex;
        flex-direction: column;
        box-shadow: 4px 0 24px rgba(0, 0, 0, 0.25);
        overflow: hidden;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    .leo-drawer.show {
        transform: translateX(0);
    }

    /* Drawer header (user chip) */
    .leo-drawer-header {
        position: relative;
        padding: 1.25rem 1rem;
        background: rgba(255, 255, 255, 0.08);
        border-bottom: 1px solid rgba(255, 255, 255, 0.15);
        flex-shrink: 0;
    }
    .leo-drawer-close {
        position: absolute;
        top: 0.75rem;
        right: 0.75rem;
        width: 36px; height: 36px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.15);
        color: #fff;
        border: none;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1rem;
        transition: background .2s;
    }
    .leo-drawer-close:hover { background: rgba(255, 255, 255, 0.28); }

    .leo-drawer-user {
        display: flex;
        align-items: center;
        gap: 0.85rem;
        margin-top: 0.5rem;
    }
    .leo-drawer-avatar {
        width: 52px; height: 52px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.22);
        border: 2px solid rgba(255, 255, 255, 0.35);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.35rem;
        color: #fff;
        flex-shrink: 0;
    }
    .leo-drawer-user-info { min-width: 0; }
    .leo-drawer-user-name {
        font-weight: 700;
        font-size: 1rem;
        color: #fff;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .leo-drawer-user-role {
        font-size: 0.8rem;
        color: rgba(255, 255, 255, 0.75);
        margin-top: 2px;
    }

    /* Drawer body (scrollable) */
    .leo-drawer-body {
        flex: 1;
        overflow-y: auto;
        padding: 0.5rem 0;
        -webkit-overflow-scrolling: touch;
        overscroll-behavior: contain;
    }
    .leo-drawer-body::-webkit-scrollbar { width: 6px; }
    .leo-drawer-body::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, 0.25);
        border-radius: 3px;
    }

    /* Sections */
    .leo-drawer-section { padding: 0.35rem 0.9rem 0.6rem; }
    .leo-drawer-section-title {
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: rgba(255, 255, 255, 0.62);
        padding: 0.7rem 0.5rem 0.4rem;
    }

    /* Items */
    .leo-drawer-item {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        padding: 0.7rem 0.75rem;
        border-radius: 10px;
        color: #ffffff;
        text-decoration: none;
        font-size: 0.92rem;
        font-weight: 500;
        transition: background .15s ease, transform .1s ease;
        margin-bottom: 2px;
    }
    .leo-drawer-item:hover,
    .leo-drawer-item:focus {
        background: rgba(255, 255, 255, 0.14);
    }
    .leo-drawer-item:active { transform: scale(0.98); }
    .leo-drawer-item.active {
        background: rgba(255, 255, 255, 0.22);
        font-weight: 700;
    }

    /* Icon chip inside each item */
    .leo-drawer-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 32px; height: 32px;
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.16);
        color: #ffffff;
        font-size: 0.9rem;
        flex-shrink: 0;
    }
    .leo-drawer-item.active .leo-drawer-icon,
    .leo-drawer-item:hover .leo-drawer-icon {
        background: rgba(255, 255, 255, 0.28);
    }

    /* Logout (pinned bottom) */
    .leo-drawer-logout {
        display: flex;
        align-items: center;
        gap: 0.65rem;
        padding: 1rem;
        background: rgba(0, 0, 0, 0.18);
        color: #ffffff;
        text-decoration: none;
        font-weight: 600;
        font-size: 0.95rem;
        border-top: 1px solid rgba(255, 255, 255, 0.15);
        flex-shrink: 0;
        transition: background .2s;
    }
    .leo-drawer-logout:hover { background: rgba(0, 0, 0, 0.30); }

    /* Lock body scroll when drawer is open */
    body.leo-drawer-open { overflow: hidden; }
</style>

<!-- BACKDROP -->
<div class="leo-drawer-backdrop" id="leoDrawerBackdrop" onclick="closeDrawer()"></div>

<!-- DRAWER -->
<aside class="leo-drawer" id="leoDrawer" aria-hidden="true">

    <div class="leo-drawer-header">
        <button class="leo-drawer-close" onclick="closeDrawer()" aria-label="Close menu">
            <i class="fas fa-times"></i>
        </button>
        <div class="leo-drawer-user">
            <div class="leo-drawer-avatar"><i class="fas fa-user"></i></div>
            <div class="leo-drawer-user-info">
                <div class="leo-drawer-user-name"><?= htmlspecialchars($__user) ?></div>
                <div class="leo-drawer-user-role"><?= htmlspecialchars($__role) ?></div>
            </div>
        </div>
    </div>

    <div class="leo-drawer-body">

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Quick Access</div>
            <a href="product-add.php"  class="leo-drawer-item <?= drawer_active('product-add.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-cubes"></i></span> Record Products
            </a>
            <a href="customer-add.php" class="leo-drawer-item <?= drawer_active('customer-add.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-user-plus"></i></span> Record Customers
            </a>
            <a href="sale-add.php"     class="leo-drawer-item <?= drawer_active('sale-add.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-cart-plus"></i></span> Record Sales
            </a>
            <a href="purchase-add.php" class="leo-drawer-item <?= drawer_active('purchase-add.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-shopping-bag"></i></span> Record Purchases
            </a>
            <a href="expense-add.php"  class="leo-drawer-item <?= drawer_active('expense-add.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-file-invoice-dollar"></i></span> Record Expenses
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Dashboard</div>
            <a href="index.php" class="leo-drawer-item <?= drawer_active('index.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-th-large"></i></span> View Dashboard
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Payments</div>
            <a href="payment-modes.php" class="leo-drawer-item <?= drawer_active('payment-modes.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-credit-card"></i></span> Modes of Payment
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">People</div>
            <a href="customers.php" class="leo-drawer-item <?= drawer_active(['customers.php','customer-edit.php','customer-view.php'], $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-users"></i></span> Customers
            </a>
            <a href="suppliers.php" class="leo-drawer-item <?= drawer_active('suppliers.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-truck"></i></span> Suppliers
            </a>
            <a href="employees.php" class="leo-drawer-item <?= drawer_active('employees.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-user-tie"></i></span> Employees
            </a>
            <a href="dues.php" class="leo-drawer-item <?= drawer_active('dues.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-file-invoice-dollar"></i></span> Dues List
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Supplies / Deliveries</div>
            <a href="supplies.php" class="leo-drawer-item <?= drawer_active('supplies.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-box-open"></i></span> Supplies
            </a>
            <a href="supply-guide.php" class="leo-drawer-item <?= drawer_active('supply-guide.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-circle-question"></i></span> Supplies Guide
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Products Management</div>
            <a href="products.php"   class="leo-drawer-item <?= drawer_active('products.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-gift"></i></span> Products List
            </a>
            <a href="categories.php" class="leo-drawer-item <?= drawer_active('categories.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-list"></i></span> Product Category
            </a>
            <a href="brands.php"     class="leo-drawer-item <?= drawer_active('brands.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-tag"></i></span> Brands
            </a>
            <a href="units.php"      class="leo-drawer-item <?= drawer_active('units.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-layer-group"></i></span> Units
            </a>
            <a href="taxes.php"      class="leo-drawer-item <?= drawer_active('taxes.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-file-invoice"></i></span> Taxes
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Inventory Management</div>
            <a href="stock-adjustment.php"   class="leo-drawer-item <?= drawer_active('stock-adjustment.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-boxes"></i></span> Stock Adjustment
            </a>
            <a href="stock-transfer.php"     class="leo-drawer-item <?= drawer_active('stock-transfer.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-exchange-alt"></i></span> Stock Transfer
            </a>
            <a href="adjustment-history.php" class="leo-drawer-item <?= drawer_active('adjustment-history.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-history"></i></span> Adjustment History
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Service Management</div>
            <a href="services.php" class="leo-drawer-item <?= drawer_active('services.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-hands-helping"></i></span> Services
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Cashbook</div>
            <a href="cashbook.php" class="leo-drawer-item <?= drawer_active('cashbook.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-book"></i></span> View Cashbook
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Sales</div>
            <a href="sales.php"          class="leo-drawer-item <?= drawer_active('sales.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-shopping-cart"></i></span> Sales List
            </a>
            <a href="sales-return.php"   class="leo-drawer-item <?= drawer_active('sales-return.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-undo"></i></span> Sales Return
            </a>
            <a href="proforma.php"       class="leo-drawer-item <?= drawer_active('proforma.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-file-alt"></i></span> Proforma Invoice
            </a>
            <a href="delivery-notes.php" class="leo-drawer-item <?= drawer_active('delivery-notes.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-truck"></i></span> Delivery Notes
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Purchases</div>
            <a href="purchases.php"            class="leo-drawer-item <?= drawer_active('purchases.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-clipboard-list"></i></span> Purchases List
            </a>
            <a href="purchases-return.php"     class="leo-drawer-item <?= drawer_active('purchases-return.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-file-import"></i></span> Purchases Return
            </a>
            <a href="purchase-procurement.php" class="leo-drawer-item <?= drawer_active('purchase-procurement.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-file-invoice"></i></span> Purchase Procurement
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Expenses</div>
            <a href="expenses.php"           class="leo-drawer-item <?= drawer_active('expenses.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-wallet"></i></span> Expenses List
            </a>
            <a href="expense-categories.php" class="leo-drawer-item <?= drawer_active('expense-categories.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-folder"></i></span> Expenses Category
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">Product Price</div>
            <a href="product-price.php"          class="leo-drawer-item <?= drawer_active('product-price.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-money-bill-wave"></i></span> Product Price
            </a>
            <a href="product-purchase-price.php" class="leo-drawer-item <?= drawer_active('product-purchase-price.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-money-check-alt"></i></span> Purchase Price
            </a>
        </div>

        <div class="leo-drawer-section">
            <div class="leo-drawer-section-title">System</div>
            <a href="recycle-bin.php"       class="leo-drawer-item <?= drawer_active('recycle-bin.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-recycle"></i></span> Recycle Bin
            </a>
            <a href="recycle-bin-guide.php" class="leo-drawer-item <?= drawer_active('recycle-bin-guide.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-circle-question"></i></span> Recycle Bin Guide
            </a>
            <a href="settings.php"          class="leo-drawer-item <?= drawer_active('settings.php', $__cur) ?>">
                <span class="leo-drawer-icon"><i class="fas fa-cog"></i></span> Settings
            </a>
        </div>

    </div>

    <a href="logout.php" class="leo-drawer-logout" onclick="return confirm('Logout?')">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
</aside>

<script>
(function () {
    'use strict';

    window.openDrawer = function () {
        var d = document.getElementById('leoDrawer');
        var b = document.getElementById('leoDrawerBackdrop');
        if (!d || !b) return;
        d.classList.add('show');
        b.classList.add('show');
        d.setAttribute('aria-hidden', 'false');
        document.body.classList.add('leo-drawer-open');
    };

    window.closeDrawer = function () {
        var d = document.getElementById('leoDrawer');
        var b = document.getElementById('leoDrawerBackdrop');
        if (!d || !b) return;
        d.classList.remove('show');
        b.classList.remove('show');
        d.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('leo-drawer-open');
    };

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') window.closeDrawer();
    });

    var __touchStartX = 0;
    document.addEventListener('touchstart', function (e) {
        __touchStartX = e.touches[0].clientX;
    }, { passive: true });

    document.addEventListener('touchend', function (e) {
        var d = document.getElementById('leoDrawer');
        if (!d) return;
        var dx = e.changedTouches[0].clientX - __touchStartX;
        if (dx > 80 && __touchStartX < 40) window.openDrawer();
        if (dx < -80 && d.classList.contains('show')) window.closeDrawer();
    }, { passive: true });
})();
</script>