<?php
// 404.php — custom error page for InfinityFree
http_response_code(404);

// Safe referrer handling
$referrer = $_SERVER['HTTP_REFERER'] ?? '';
$safeBack = 'index.php'; // fallback

if ($referrer !== '') {
    $host = parse_url($referrer, PHP_URL_HOST);
    $ourHost = $_SERVER['HTTP_HOST'] ?? '';
    if ($host && $host === $ourHost) {
        $safeBack = $referrer;
    }
}

// 2-second auto-redirect via PHP header (works without JS)
header('Refresh: 2; url=' . $safeBack);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 — Page Not Found</title>
    <meta http-equiv="refresh" content="2;url=<?= htmlspecialchars($safeBack) ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #EFF6FF 0%, #F8FAFC 100%);
            color: #1E293B;
            padding: 1.2rem;
        }
        .box {
            background: #fff;
            border-radius: 20px;
            padding: 2.2rem 1.8rem 2rem;
            max-width: 420px;
            width: 100%;
            text-align: center;
            box-shadow: 0 12px 40px rgba(15, 23, 42, 0.08);
            animation: fadeInUp 0.45s ease both;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(14px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .icon-wrap {
            width: 84px;
            height: 84px;
            border-radius: 50%;
            background: #FEF3C7;
            color: #92400E;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 2.2rem;
            margin-bottom: 1rem;
            animation: pulse 1.6s ease-in-out infinite;
        }
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50%      { transform: scale(1.05); }
        }
        h1 {
            font-size: 1.55rem;
            margin: 0 0 0.35rem;
            color: #0F172A;
        }
        .code {
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: #94A3B8;
            margin-bottom: 1rem;
        }
        p {
            font-size: 0.95rem;
            line-height: 1.5;
            color: #475569;
            margin: 0 0 1.4rem;
        }
        .progress {
            height: 4px;
            width: 100%;
            background: #E2E8F0;
            border-radius: 999px;
            overflow: hidden;
            margin-bottom: 1.4rem;
        }
        .progress-bar {
            height: 100%;
            width: 100%;
            background: linear-gradient(90deg, #1E40AF, #3B82F6);
            border-radius: 999px;
            transform-origin: left center;
            animation: shrink 2s linear forwards;
        }
        @keyframes shrink {
            from { transform: scaleX(1); }
            to   { transform: scaleX(0); }
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            width: 100%;
            padding: 0.85rem 1rem;
            border-radius: 12px;
            font-size: 0.95rem;
            font-weight: 600;
            text-decoration: none;
            background: #1E40AF;
            color: #fff;
            border: none;
            cursor: pointer;
            transition: transform 0.15s ease, background 0.15s ease;
        }
        .btn:active { transform: scale(0.98); }
        .btn:hover  { background: #1D4ED8; }
        .btn-outline {
            background: #F1F5F9;
            color: #334155;
            margin-top: 0.6rem;
        }
        .btn-outline:hover { background: #E2E8F0; }
        .countdown {
            font-size: 0.8rem;
            color: #64748B;
            margin-top: 0.9rem;
        }
        .countdown strong { color: #1E40AF; }
    </style>
</head>
<body>
    <div class="box">
        <div class="icon-wrap">
            <i class="fas fa-compass"></i>
        </div>
        <div class="code">Error 404</div>
        <h1>Sorry, Mwalimu</h1>
        <p>The page you were looking for doesn't exist or has moved. We'll take you back in a moment.</p>

        <div class="progress"><div class="progress-bar"></div></div>

        <a href="<?= htmlspecialchars($safeBack) ?>" class="btn">
            <i class="fas fa-arrow-left"></i> Go back to previous page
        </a>
        <a href="index.php" class="btn btn-outline">
            <i class="fas fa-home"></i> Go to Home
        </a>

        <div class="countdown">
            Redirecting in <strong id="secs">2</strong> second<span id="secsS">s</span>...
        </div>
    </div>

    <script>
        let s = 2;
        const el = document.getElementById('secs');
        const elS = document.getElementById('secsS');
        const timer = setInterval(function() {
            s--;
            if (s <= 0) {
                clearInterval(timer);
                window.location.href = <?= json_encode($safeBack) ?>;
            } else {
                el.textContent = s;
                if (s === 1) elS.textContent = '';
            }
        }, 1000);
    </script>
</body>
</html>