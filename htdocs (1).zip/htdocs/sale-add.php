<?php
$page_title = 'Add Sales';
require_once __DIR__ . '/config/db.php';

/* ---------- Next invoice number ---------- */
$next_invoice = 'S-00001';
try {
    $last = $pdo->query("SELECT id FROM sales ORDER BY id DESC LIMIT 1")->fetchColumn();
    if ($last) $next_invoice = 'S-' . str_pad($last + 1, 5, '0', STR_PAD_LEFT);
} catch (Exception $e) {}

/* ---------- Load products for the picker ---------- */
$products = [];
try {
    $products = $pdo->query("SELECT id, product_name, price FROM products ORDER BY product_name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}

/* ---------- Handle SAVE ---------- */
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();

        $invoice  = $_POST['invoice_no'] ?? $next_invoice;
        $customer = trim($_POST['customer_name'] ?? 'Walk-in Customer');
        $phone    = trim($_POST['customer_phone'] ?? '');
        $subtotal = floatval($_POST['subtotal'] ?? 0);
        $discount = floatval($_POST['discount'] ?? 0);
        $tax      = floatval($_POST['tax'] ?? 0);
        $shipping = floatval($_POST['shipping'] ?? 0);
        $grand    = floatval($_POST['grand_total'] ?? 0);
        $received = floatval($_POST['amount_received'] ?? 0);
        $due      = floatval($_POST['amount_due'] ?? 0);
        $note     = trim($_POST['note'] ?? '');

        $stmt = $pdo->prepare("INSERT INTO sales
            (invoice_no, customer_name, customer_phone, subtotal, discount, tax, shipping, grand_total, amount_received, amount_due, note, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())");
        $stmt->execute([$invoice,$customer,$phone,$subtotal,$discount,$tax,$shipping,$grand,$received,$due,$note]);
        $sale_id = $pdo->lastInsertId();

        /* Save items */
        $items = json_decode($_POST['items_json'] ?? '[]', true);
        if (is_array($items) && count($items)) {
            $si = $pdo->prepare("INSERT INTO sale_items
                (sale_id, product_id, product_name, price, qty, unit, subtotal)
                VALUES (?,?,?,?,?,?,?)");
            foreach ($items as $it) {
                $si->execute([
                    $sale_id,
                    $it['product_id'] ?? null,
                    $it['name'] ?? '',
                    floatval($it['price'] ?? 0),
                    floatval($it['qty'] ?? 0),
                    $it['unit'] ?? '',
                    floatval($it['subtotal'] ?? 0)
                ]);
            }
        }

        $pdo->commit();
        header('Location: sales.php');
        exit;
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $msg = $e->getMessage();
    }
}

require_once __DIR__ . '/includes/header.php';
?>
<header class="leo-page-header">
    <div class="leo-page-header-left">
        <a href="sales.php" class="leo-back-btn"><i class="fas fa-chevron-left"></i></a>
        <span class="leo-page-header-title">Add Sales</span>
    </div>
    <div class="leo-page-header-actions">
        <button type="submit" form="saleForm" class="leo-save-btn">SAVE</button>
    </div>
</header>

<form method="post" id="saleForm">
<input type="hidden" name="invoice_no" value="<?php echo htmlspecialchars($next_invoice); ?>">
<input type="hidden" name="items_json" id="items_json">
<input type="hidden" name="subtotal" id="f_subtotal">
<input type="hidden" name="grand_total" id="f_grand">
<input type="hidden" name="amount_received" id="f_received">
<input type="hidden" name="amount_due" id="f_due">
<input type="hidden" name="discount" id="f_discount">
<input type="hidden" name="tax" id="f_tax">
<input type="hidden" name="shipping" id="f_shipping">

<div style="padding:0.85rem;">

    <?php if ($msg): ?>
        <div style="color:#DC2626;font-size:0.82rem;margin-bottom:0.75rem;"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <!-- Invoice + Date + Customer -->
    <div class="leo-form-card" style="margin-bottom:0.75rem;">
        <div class="leo-form-card-body">
            <div class="leo-form-row leo-form-row-inline">
                <div>
                    <label class="leo-input-label">Invoice Number</label>
                    <div style="font-size:0.92rem;color:var(--leo-ink);font-weight:600;"><?php echo $next_invoice; ?></div>
                </div>
                <div>
                    <label class="leo-input-label">Date</label>
                    <div style="font-size:0.92rem;color:var(--leo-ink);font-weight:600;"><?php echo date('Y-m-d'); ?></div>
                </div>
            </div>
            <div class="leo-form-row">
                <label class="leo-input-label">Customer Name</label>
                <input type="text" name="customer_name" class="leo-input" value="Walk-in Customer">
            </div>
            <div class="leo-form-row">
                <label class="leo-input-label">Customer Phone Number</label>
                <input type="tel" name="customer_phone" class="leo-input" placeholder="Enter customer phone number">
            </div>
        </div>
    </div>

    <!-- Add Product row -->
    <div class="leo-form-card" style="margin-bottom:0.75rem;">
        <div class="leo-form-card-body">
            <label class="leo-input-label">Add Product</label>
            <div class="leo-form-row leo-form-row-inline" style="align-items:flex-end;">
                <div style="flex:2;">
                    <select id="p_pick" class="leo-input">
                        <option value="">-- Select product --</option>
                        <?php foreach ($products as $p): ?>
                            <option value="<?php echo (int)$p['id']; ?>"
                                    data-name="<?php echo htmlspecialchars($p['product_name']); ?>"
                                    data-price="<?php echo htmlspecialchars($p['price']); ?>">
                                <?php echo htmlspecialchars($p['product_name']); ?> — <?php echo number_format((float)$p['price'], 2); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div style="flex:1;">
                    <input type="text" id="p_name" class="leo-input" placeholder="Or type name">
                </div>
                <div style="flex:1;">
                    <input type="number" id="p_price" class="leo-input" placeholder="Price" step="0.01">
                </div>
                <div style="flex:1;">
                    <input type="number" id="p_qty" class="leo-input" placeholder="Qty" step="0.01" value="1">
                </div>
                <div style="flex:1;">
                    <input type="text" id="p_unit" class="leo-input" placeholder="Unit" list="unitList">
                    <datalist id="unitList">
                        <option value="Piece (pc)"></option>
                        <option value="Kilogram (kg)"></option>
                        <option value="Gram (g)"></option>
                        <option value="Litre (L)"></option>
                        <option value="Millilitre (ml)"></option>
                        <option value="Metre (m)"></option>
                        <option value="Centimetre (cm)"></option>
                        <option value="Box"></option>
                        <option value="Pack"></option>
                        <option value="Carton"></option>
                        <option value="Dozen"></option>
                    </datalist>
                </div>
                <div style="flex:0 0 auto;">
                    <button type="button" id="btnAdd" class="leo-btn leo-btn--primary" style="white-space:nowrap;">+ Add</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Items table -->
    <div class="leo-form-card" style="margin-bottom:0.75rem;">
        <div class="leo-form-card-body" style="padding:0;">
            <table id="itemsTable" style="width:100%;border-collapse:collapse;font-size:0.85rem;">
                <thead>
                    <tr style="background:#f6f7f9;text-align:left;">
                        <th style="padding:0.55rem;">Product</th>
                        <th style="padding:0.55rem;">Price</th>
                        <th style="padding:0.55rem;">Qty</th>
                        <th style="padding:0.55rem;">Unit</th>
                        <th style="padding:0.55rem;">Subtotal</th>
                        <th style="padding:0.55rem;text-align:right;">Actions</th>
                    </tr>
                </thead>
                <tbody id="itemsBody">
                    <tr id="emptyRow"><td colspan="6" style="padding:1rem;text-align:center;color:#888;">No products added yet</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Summary -->
    <div class="leo-summary-table" style="margin-bottom:0.75rem;">
        <div class="leo-summary-row">
            <span class="leo-summary-row-label">Subtotal</span>
            <span class="leo-summary-row-value" id="s_subtotal">0</span>
        </div>
        <div class="leo-summary-row">
            <span class="leo-summary-row-label">Discount</span>
            <div style="display:flex;gap:0.5rem;align-items:center;">
                <select id="disc_type" class="leo-input" style="padding:0.35rem 0.5rem;font-size:0.8rem;width:auto;">
                    <option value="flat">Flat</option>
                    <option value="pct">%</option>
                </select>
                <input type="number" id="disc_val" class="leo-input" style="width:90px;padding:0.35rem 0.5rem;" value="0">
            </div>
        </div>
        <div class="leo-summary-row">
            <span class="leo-summary-row-label">Tax</span>
            <input type="number" id="tax_val" class="leo-input" style="width:110px;padding:0.35rem 0.5rem;" value="0">
        </div>
        <div class="leo-summary-row">
            <span class="leo-summary-row-label">Shipping Cost</span>
            <input type="number" id="ship_val" class="leo-input" style="width:110px;padding:0.35rem 0.5rem;" value="0">
        </div>
        <div class="leo-summary-row leo-summary-row--grand">
            <span class="leo-summary-row-label">Grand Total</span>
            <span class="leo-summary-row-value" id="s_grand">0</span>
        </div>
        <div class="leo-summary-row">
            <span class="leo-summary-row-label">Amount Received</span>
            <input type="number" id="rec_val" class="leo-input" style="width:110px;padding:0.35rem 0.5rem;" value="0">
        </div>
        <div class="leo-summary-row">
            <span class="leo-summary-row-label">Amount Due</span>
            <span class="leo-summary-row-value" id="s_due">0</span>
        </div>
    </div>

    <!-- Note -->
    <div class="leo-form-card" style="margin-bottom:5rem;">
        <div class="leo-form-card-body">
            <label class="leo-input-label">Note</label>
            <input type="text" name="note" class="leo-input" placeholder="Enter your opinion">
        </div>
    </div>
</div>

<div class="leo-bottom-actions">
    <a href="sales.php" class="leo-btn leo-btn--outline">CANCEL</a>
    <button type="submit" class="leo-btn leo-btn--primary">SAVE</button>
</div>
</form>

<script>
(function(){
    const items = [];
    const body = document.getElementById('itemsBody');
    const emptyRow = document.getElementById('emptyRow');

    const pick  = document.getElementById('p_pick');
    const nameI = document.getElementById('p_name');
    const priceI= document.getElementById('p_price');
    const qtyI  = document.getElementById('p_qty');
    const unitI = document.getElementById('p_unit');

    pick.addEventListener('change', function(){
        const opt = this.options[this.selectedIndex];
        if (opt.value) {
            nameI.value  = opt.dataset.name;
            priceI.value = opt.dataset.price;
        }
    });

    function fmt(n){ return Number(n||0).toFixed(2); }

    function render(){
        body.innerHTML = '';
        if (!items.length) {
            body.appendChild(emptyRow);
            emptyRow.style.display = '';
        } else {
            emptyRow.style.display = 'none';
            items.forEach((it, idx) => {
                const tr = document.createElement('tr');
                tr.style.borderTop = '1px solid #eee';
                tr.innerHTML = `
                    <td style="padding:0.5rem;" class="c-name">${it.name}</td>
                    <td style="padding:0.5rem;" class="c-price">${fmt(it.price)}</td>
                    <td style="padding:0.5rem;" class="c-qty">${it.qty}</td>
                    <td style="padding:0.5rem;" class="c-unit">${it.unit||''}</td>
                    <td style="padding:0.5rem;" class="c-sub">${fmt(it.subtotal)}</td>
                    <td style="padding:0.5rem;text-align:right;white-space:nowrap;">
                        <button type="button" class="btn-edit" data-i="${idx}" style="background:none;border:none;cursor:pointer;color:#2563EB;"><i class="fas fa-pen"></i></button>
                        <button type="button" class="btn-del" data-i="${idx}" style="background:none;border:none;cursor:pointer;color:#DC2626;margin-left:0.5rem;"><i class="fas fa-trash"></i></button>
                    </td>`;
                body.appendChild(tr);
            });
        }
        calc();
    }

    function calc(){
        let sub = 0;
        items.forEach(it => sub += Number(it.subtotal));
        const discType = document.getElementById('disc_type').value;
        const discVal  = parseFloat(document.getElementById('disc_val').value) || 0;
        let discount = discType === 'pct' ? (sub * discVal / 100) : discVal;
        const tax  = parseFloat(document.getElementById('tax_val').value) || 0;
        const ship = parseFloat(document.getElementById('ship_val').value) || 0;
        const grand = Math.max(0, sub - discount + tax + ship);
        const rec = parseFloat(document.getElementById('rec_val').value) || 0;
        const due = Math.max(0, grand - rec);

        document.getElementById('s_subtotal').textContent = fmt(sub);
        document.getElementById('s_grand').textContent    = fmt(grand);
        document.getElementById('s_due').textContent      = fmt(due);

        document.getElementById('f_subtotal').value = sub;
        document.getElementById('f_discount').value = discount;
        document.getElementById('f_tax').value      = tax;
        document.getElementById('f_shipping').value = ship;
        document.getElementById('f_grand').value    = grand;
        document.getElementById('f_received').value = rec;
        document.getElementById('f_due').value      = due;
        document.getElementById('items_json').value = JSON.stringify(items);
    }

    document.getElementById('btnAdd').addEventListener('click', function(){
        const name = nameI.value.trim();
        const price = parseFloat(priceI.value) || 0;
        const qty = parseFloat(qtyI.value) || 0;
        const unit = unitI.value.trim();
        const pid = pick.value ? parseInt(pick.value) : null;
        if (!name || qty <= 0) { alert('Enter product name and quantity'); return; }
        items.push({ product_id: pid, name, price, qty, unit, subtotal: price*qty });
        // reset
        pick.value=''; nameI.value=''; priceI.value=''; qtyI.value='1'; unitI.value='';
        render();
    });

    body.addEventListener('click', function(e){
        const editBtn = e.target.closest('.btn-edit');
        const delBtn  = e.target.closest('.btn-del');
        if (delBtn) {
            items.splice(parseInt(delBtn.dataset.i), 1);
            render();
        }
        if (editBtn) {
            const i = parseInt(editBtn.dataset.i);
            const it = items[i];
            const tr = editBtn.closest('tr');
            tr.querySelector('.c-name').innerHTML  = `<input class="leo-input" style="padding:0.25rem;" value="${it.name}">`;
            tr.querySelector('.c-price').innerHTML = `<input type="number" class="leo-input" style="padding:0.25rem;width:80px;" value="${it.price}">`;
            tr.querySelector('.c-qty').innerHTML   = `<input type="number" class="leo-input" style="padding:0.25rem;width:60px;" value="${it.qty}">`;
            tr.querySelector('.c-unit').innerHTML  = `<input class="leo-input" style="padding:0.25rem;width:80px;" value="${it.unit||''}">`;
            tr.querySelector('.c-sub').innerHTML   = `<span>${fmt(it.subtotal)}</span>`;
            const actions = tr.querySelector('td:last-child');
            actions.innerHTML = `
                <button type="button" class="btn-save" style="background:none;border:none;cursor:pointer;color:#16A34A;"><i class="fas fa-check"></i></button>
                <button type="button" class="btn-cancel" style="background:none;border:none;cursor:pointer;color:#888;margin-left:0.5rem;"><i class="fas fa-times"></i></button>`;

            actions.querySelector('.btn-save').addEventListener('click', function(){
                const n = tr.querySelector('.c-name input').value.trim();
                const p = parseFloat(tr.querySelector('.c-price input').value) || 0;
                const q = parseFloat(tr.querySelector('.c-qty input').value) || 0;
                const u = tr.querySelector('.c-unit input').value.trim();
                items[i] = { product_id: it.product_id, name:n, price:p, qty:q, unit:u, subtotal:p*q };
                render();
            });
            actions.querySelector('.btn-cancel').addEventListener('click', render);
        }
    });

    ['disc_type','disc_val','tax_val','ship_val','rec_val'].forEach(id => {
        document.getElementById(id).addEventListener('input', calc);
        document.getElementById(id).addEventListener('change', calc);
    });

    render();
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>