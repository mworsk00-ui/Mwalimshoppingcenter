<?php
$page_title = 'Edit Product';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/flash.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    flash('error', 'Invalid product ID.');
    header('Location: products.php');
    exit;
}

// Fetch product
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? AND deleted_at IS NULL");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    flash('error', 'Product not found.');
    header('Location: products.php');
    exit;
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name       = trim($_POST['product_name'] ?? '');
    $price      = (float)($_POST['price'] ?? 0);
    $purchase   = (float)($_POST['purchase_price'] ?? 0);
    $wholesale  = (float)($_POST['wholesale_price'] ?? 0);
    $dealer     = (float)($_POST['dealer_price'] ?? 0);
    $stock      = (int)($_POST['stock_qty'] ?? 0);
    $unit       = trim($_POST['unit'] ?? 'pcs');
    $barcode    = trim($_POST['barcode'] ?? '');
    $category   = trim($_POST['category'] ?? '');
    $brand      = trim($_POST['brand'] ?? '');
    $low_stock  = (int)($_POST['low_stock'] ?? 5);
    $expiry     = $_POST['expiry_date'] ?: null;
    $notes      = trim($_POST['notes'] ?? '');
    $status     = ($_POST['status'] ?? 'Active') === 'Inactive' ? 'Inactive' : 'Active';

    if ($name === '') {
        flash('error', 'Product name is required.');
    } else {
        try {
            $up = $pdo->prepare("
                UPDATE products SET
                    product_name = ?, price = ?, purchase_price = ?, wholesale_price = ?,
                    dealer_price = ?, stock_qty = ?, unit = ?, barcode = ?,
                    category = ?, brand = ?, low_stock = ?, expiry_date = ?,
                    notes = ?, status = ?
                WHERE id = ?
            ");
            $up->execute([
                $name, $price, $purchase, $wholesale,
                $dealer, $stock, $unit, $barcode,
                $category, $brand, $low_stock, $expiry,
                $notes, $status, $id
            ]);
            flash('success', 'Product updated successfully.');
            header('Location: products.php');
            exit;
        } catch (PDOException $e) {
            flash('error', 'Could not update product: ' . $e->getMessage());
        }
    }
    // Re-fetch in case of error
    $stmt->execute([$id]);
    $product = $stmt->fetch();
}

require_once __DIR__ . '/includes/header.php';
?>

<header class="leo-page-header">
    <div class="leo-page-header-left">
        <a href="products.php" class="leo-back-btn"><i class="fas fa-chevron-left"></i></a>
        <span class="leo-page-header-title">Edit Product</span>
    </div>
</header>

<form method="post" class="leo-form-card" style="margin:0.85rem;padding:1rem;display:grid;gap:0.85rem;">

    <div>
        <label class="leo-input-label">Product Name *</label>
        <input type="text" name="product_name" required class="leo-input"
               value="<?= htmlspecialchars($product['product_name']) ?>">
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.6rem;">
        <div>
            <label class="leo-input-label">Selling Price</label>
            <input type="number" step="0.01" name="price" class="leo-input"
                   value="<?= htmlspecialchars($product['price']) ?>">
        </div>
        <div>
            <label class="leo-input-label">Purchase Price</label>
            <input type="number" step="0.01" name="purchase_price" class="leo-input"
                   value="<?= htmlspecialchars($product['purchase_price']) ?>">
        </div>
        <div>
            <label class="leo-input-label">Wholesale Price</label>
            <input type="number" step="0.01" name="wholesale_price" class="leo-input"
                   value="<?= htmlspecialchars($product['wholesale_price']) ?>">
        </div>
        <div>
            <label class="leo-input-label">Dealer Price</label>
            <input type="number" step="0.01" name="dealer_price" class="leo-input"
                   value="<?= htmlspecialchars($product['dealer_price']) ?>">
        </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.6rem;">
        <div>
            <label class="leo-input-label">Stock Qty</label>
            <input type="number" name="stock_qty" class="leo-input"
                   value="<?= (int)$product['stock_qty'] ?>">
        </div>
        <div>
            <label class="leo-input-label">Unit</label>
            <input type="text" name="unit" class="leo-input"
                   value="<?= htmlspecialchars($product['unit']) ?>">
        </div>
        <div>
            <label class="leo-input-label">Low Stock Alert</label>
            <input type="number" name="low_stock" class="leo-input"
                   value="<?= (int)$product['low_stock'] ?>">
        </div>
        <div>
            <label class="leo-input-label">Barcode</label>
            <input type="text" name="barcode" class="leo-input"
                   value="<?= htmlspecialchars($product['barcode'] ?? '') ?>">
        </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.6rem;">
        <div>
            <label class="leo-input-label">Category</label>
            <input type="text" name="category" class="leo-input"
                   value="<?= htmlspecialchars($product['category'] ?? '') ?>">
        </div>
        <div>
            <label class="leo-input-label">Brand</label>
            <input type="text" name="brand" class="leo-input"
                   value="<?= htmlspecialchars($product['brand'] ?? '') ?>">
        </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.6rem;">
        <div>
            <label class="leo-input-label">Expiry Date</label>
            <input type="date" name="expiry_date" class="leo-input"
                   value="<?= htmlspecialchars($product['expiry_date'] ?? '') ?>">
        </div>
        <div>
            <label class="leo-input-label">Status</label>
            <select name="status" class="leo-input">
                <option value="Active"   <?= ($product['status'] ?? 'Active') === 'Active'   ? 'selected' : '' ?>>Active</option>
                <option value="Inactive" <?= ($product['status'] ?? 'Active') === 'Inactive' ? 'selected' : '' ?>>Inactive (Hidden)</option>
            </select>
        </div>
    </div>

    <div>
        <label class="leo-input-label">Notes</label>
        <textarea name="notes" class="leo-input" rows="3"><?= htmlspecialchars($product['notes'] ?? '') ?></textarea>
    </div>

    <div style="display:flex;gap:0.6rem;justify-content:flex-end;">
        <a href="products.php" class="leo-btn leo-btn--outline" style="padding:0.65rem 1rem;">Cancel</a>
        <button type="submit" class="leo-btn leo-btn--primary" style="padding:0.65rem 1rem;">
            <i class="fas fa-save"></i> Save Changes
        </button>
    </div>
</form>

<?php require_once __DIR__ . '/includes/footer.php'; ?>