-- Mwalimshoppingcenter Database Schema

DROP TABLE IF EXISTS users, customers, products, sales, expenses, settings;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    role VARCHAR(20) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100),
    customer_type VARCHAR(30) DEFAULT 'Retailer',
    tin VARCHAR(50),
    address TEXT,
    due_amount DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    brand VARCHAR(50),
    barcode VARCHAR(50),
    purchase_price DECIMAL(10,2) DEFAULT 0,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    wholesale_price DECIMAL(10,2) DEFAULT 0,
    dealer_price DECIMAL(10,2) DEFAULT 0,
    stock_qty INT NOT NULL DEFAULT 0,
    low_stock INT DEFAULT 5,
    unit VARCHAR(20),
    expiry_date DATE NULL,
    image VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_no VARCHAR(30),
    product_id INT,
    customer_id INT,
    quantity INT DEFAULT 1,
    subtotal DECIMAL(10,2) DEFAULT 0,
    discount DECIMAL(10,2) DEFAULT 0,
    tax DECIMAL(10,2) DEFAULT 0,
    shipping DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    amount_received DECIMAL(10,2) DEFAULT 0,
    amount_due DECIMAL(10,2) DEFAULT 0,
    payment_status VARCHAR(20) DEFAULT 'paid',
    payment_mode VARCHAR(30) DEFAULT 'Cash Pay',
    is_service TINYINT(1) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    expense_for VARCHAR(100),
    category VARCHAR(50),
    payment_mode VARCHAR(30) DEFAULT 'Cash Pay',
    title VARCHAR(100),
    amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    reference_no VARCHAR(50),
    reference_doc VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100),
    tin VARCHAR(50),
    address TEXT,
    due_amount DECIMAL(10,2) DEFAULT 0,
    bank_name VARCHAR(100),
    account_name VARCHAR(100),
    account_number VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    service_code VARCHAR(50),
    unit VARCHAR(30),
    cost DECIMAL(10,2) DEFAULT 0,
    price DECIMAL(10,2) DEFAULT 0,
    profit_type VARCHAR(20) DEFAULT 'Flat',
    profit_margin DECIMAL(10,2) DEFAULT 0,
    expiry_date DATE NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE settings (
    setting_key VARCHAR(50) PRIMARY KEY,
    setting_value TEXT
);

INSERT INTO users (username, password, full_name, role)
VALUES ('admin', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1HlCS4bZJ18JYy7BHqYBqAYK5Wm5rG', 'Administrator', 'admin');

INSERT INTO settings (setting_key, setting_value) VALUES
('monthly_target', '0'),
('package', 'Free Package'),
('expires_on', DATE_ADD(CURDATE(), INTERVAL 4 DAY));
