<?php
$page_title = 'Reports';
require_once __DIR__ . '/config/db.php';

/* ---------- Helpers ---------- */
function q($pdo, $sql, $params = []) {
    try { $st = $pdo->prepare($sql); $st->execute($params); return $st->fetchAll(PDO::FETCH_ASSOC); }
    catch (Exception $e) { return []; }
}
function money($n) { return number_format((float)$n, 2); }

/* =========================================================
   BUSINESS INSIGHTS
   ========================================================= */
$bi_today_sales   = q($pdo, "SELECT COALESCE(SUM(total_amount),0) t FROM sales WHERE DATE(created_at)=CURDATE() AND deleted_at IS NULL")[0]['t'] ?? 0;
$bi_month_sales   = q($pdo, "SELECT COALESCE(SUM(total_amount),0) t FROM sales WHERE MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE()) AND deleted_at IS NULL")[0]['t'] ?? 0;
$bi_month_expense = q($pdo, "SELECT COALESCE(SUM(amount),0) t FROM expenses WHERE MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE()) AND deleted_at IS NULL")[0]['t'] ?? 0;
$bi_products      = q($pdo, "SELECT COUNT(*) c FROM products WHERE deleted_at IS NULL")[0]['c'] ?? 0;
$bi_customers     = q($pdo, "SELECT COUNT(*) c FROM customers WHERE deleted_at IS NULL")[0]['c'] ?? 0;
$bi_low_stock     = q($pdo, "SELECT COUNT(*) c FROM products WHERE stock_qty <= low_stock AND deleted_at IS NULL")[0]['c'] ?? 0;
$bi_dues          = q($pdo, "SELECT COALESCE(SUM(amount_due),0) t FROM sales WHERE deleted_at IS NULL")[0]['t'] ?? 0;

/* =========================================================
   EMPLOYEE
   ========================================================= */
$employees = q($pdo, "SELECT * FROM employees WHERE deleted_at IS NULL ORDER BY employee_name ASC");

/* =========================================================
   PRODUCTS PERFORMANCE
   ========================================================= */
$prod_perf = q($pdo, "SELECT si.product_name,
                        SUM(si.quantity) qty_sold,
                        SUM(si.subtotal) revenue
                      FROM sale_items si
                      JOIN sales s ON s.id = si.sale_id
                      WHERE s.deleted_at IS NULL
                      GROUP BY si.product_name
                      ORDER BY revenue DESC");

/* =========================================================
   INVENTORY
   ========================================================= */
$inventory = q($pdo, "SELECT product_name, stock_qty, unit, low_stock, price
                      FROM products WHERE deleted_at IS NULL
                      ORDER BY stock_qty ASC");

/* =========================================================
   PURCHASES
   ========================================================= */
$purchases = q($pdo, "SELECT * FROM purchases_list WHERE deleted_at IS NULL ORDER BY purchase_date DESC, id DESC");

/* =========================================================
   PROFIT & LOSS
   ========================================================= */
$revenue  = q($pdo, "SELECT COALESCE(SUM(total_amount),0) t FROM sales WHERE deleted_at IS NULL")[0]['t'] ?? 0;
$cost     = q($pdo, "SELECT COALESCE(SUM(si.quantity * COALESCE(p.purchase_price,0)),0) t
                     FROM sale_items si
                     LEFT JOIN products p ON p.id = si.product_id
                     JOIN sales s ON s.id = si.sale_id
                     WHERE s.deleted_at IS NULL")[0]['t'] ?? 0;
$expenses = q($pdo, "SELECT COALESCE(SUM(amount),0) t FROM expenses WHERE deleted_at IS NULL")[0]['t'] ?? 0;
$pl_profit = $revenue - $cost - $expenses;

/* =========================================================
   DUES
   ========================================================= */
$dues = q($pdo, "SELECT s.id, s.invoice_no, s.total_amount, s.amount_received, s.amount_due, s.created_at,
                        COALESCE(c.customer_name,'Walk-in') customer_name, c.phone
                 FROM sales s
                 LEFT JOIN customers c ON c.id = s.customer_id
                 WHERE s.amount_due > 0 AND s.deleted_at IS NULL
                 ORDER BY s.created_at DESC");

/* =========================================================
   EXPENSES
   ========================================================= */
$expenses_list = q($pdo, "SELECT * FROM expenses WHERE deleted_at IS NULL ORDER BY created_at DESC");

/* =========================================================
   CUSTOMERS
   ========================================================= */
$customers = q($pdo, "SELECT * FROM customers WHERE deleted_at IS NULL ORDER BY customer_name ASC");

/* =========================================================
   SERVICES
   ========================================================= */
$services = q($pdo, "SELECT * FROM services WHERE deleted_at IS NULL ORDER BY service_name ASC");

/* =========================================================
   STOCK
   ========================================================= */
$stock = q($pdo, "SELECT product_name, stock_qty, unit, purchase_price, price,
                         (stock_qty * purchase_price) stock_value
                  FROM products WHERE deleted_at IS NULL
                  ORDER BY product_name ASC");
$stock_total_value = 0; foreach ($stock as $s) $stock_total_value += (float)$s['stock_value'];

require_once __DIR__ . '/includes/header.php';
?>

<style>
.rpt-section{margin:0.85rem;}
.rpt-head{
    display:flex;justify-content:space-between;align-items:center;gap:0.5rem;
    background:#fff;border-radius:12px;padding:0.75rem 0.9rem;
    box-shadow:0 1px 3px rgba(0,0,0,0.05);cursor:pointer;
    border-left:4px solid var(--leo-primary);
    transition:background 0.15s;
}
.rpt-head:hover{background:var(--leo-blue-soft);}
.rpt-head h3{font-size:0.92rem;font-weight:700;color:var(--leo-primary);margin:0;display:flex;align-items:center;gap:0.5rem;}
.rpt-head .rpt-chev{color:var(--leo-primary);transition:transform 0.2s;}
.rpt-head.open .rpt-chev{transform:rotate(90deg);}
.rpt-head .rpt-actions{display:flex;gap:0.4rem;align-items:center;}
.rpt-btn{
    background:var(--leo-blue-soft);color:var(--leo-primary);border:0;border-radius:8px;
    padding:0.35rem 0.6rem;font-size:0.75rem;font-weight:600;cursor:pointer;
    display:inline-flex;align-items:center;gap:0.3rem;
}
.rpt-btn:hover{background:var(--leo-primary);color:#fff;}

.rpt-body{
    max-height:0;overflow:hidden;
    transition:max-height 0.3s ease;
    background:transparent;
}
.rpt-body.open{max-height:6000px;}
.rpt-body-inner{background:#fff;border-radius:12px;padding:0.75rem;margin-top:0.4rem;box-shadow:0 1px 3px rgba(0,0,0,0.04);}

.rpt-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:0.5rem;}
.rpt-kpi{background:var(--leo-blue-soft);padding:0.7rem;border-radius:10px;text-align:center;}
.rpt-kpi .v{font-size:1.05rem;font-weight:800;color:var(--leo-primary);}
.rpt-kpi .l{font-size:0.7rem;color:var(--leo-muted);margin-top:0.15rem;}
table.rpt-tbl{width:100%;border-collapse:collapse;font-size:0.8rem;}
table.rpt-tbl th,table.rpt-tbl td{padding:0.45rem 0.5rem;text-align:left;border-bottom:1px solid #EEF1F5;}
table.rpt-tbl th{background:#f7f9fc;color:var(--leo-muted);font-weight:600;font-size:0.72rem;text-transform:uppercase;}
table.rpt-tbl tr:last-child td{border-bottom:none;}
.empty{color:#999;font-size:0.82rem;padding:0.75rem;text-align:center;}
.rpt-sub{font-size:0.75rem;color:var(--leo-muted);margin:0 0 0.4rem 0;}
.rpt-toggle{display:block;margin:0.5rem auto 0;background:none;border:1px dashed var(--leo-primary);color:var(--leo-primary);font-weight:600;font-size:0.78rem;padding:0.35rem 0.8rem;border-radius:20px;cursor:pointer;}
.rpt-toggle:hover{background:var(--leo-blue-soft);}
.rpt-tbl tbody tr.hidden-row{display:none;}

@media print {
    body * { visibility: hidden; }
    .printing, .printing * { visibility: visible; }
    .printing { position:absolute; left:0; top:0; width:100%; }
    .rpt-toggle, .rpt-actions, .rpt-head { display:none !important; }
    .rpt-body { max-height:none !important; overflow:visible !important; }
    .rpt-tbl tbody tr.hidden-row { display:table-row !important; }
}
</style>

<!-- ================= BUSINESS INSIGHTS ================= -->
<div class="rpt-section" id="sec-bi">
    <div class="rpt-head" onclick="toggleSection('sec-bi')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-th-large"></i> Business Insights</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-bi')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-bi-body">
        <div class="rpt-body-inner">
            <div class="rpt-grid">
                <div class="rpt-kpi"><div class="v"><?php echo money($bi_today_sales); ?></div><div class="l">Today Sales</div></div>
                <div class="rpt-kpi"><div class="v"><?php echo money($bi_month_sales); ?></div><div class="l">This Month Sales</div></div>
                <div class="rpt-kpi"><div class="v"><?php echo money($bi_month_expense); ?></div><div class="l">Month Expenses</div></div>
                <div class="rpt-kpi"><div class="v"><?php echo (int)$bi_products; ?></div><div class="l">Products</div></div>
                <div class="rpt-kpi"><div class="v"><?php echo (int)$bi_customers; ?></div><div class="l">Customers</div></div>
                <div class="rpt-kpi"><div class="v" style="color:#DC2626;"><?php echo (int)$bi_low_stock; ?></div><div class="l">Low Stock</div></div>
                <div class="rpt-kpi"><div class="v" style="color:#DC2626;"><?php echo money($bi_dues); ?></div><div class="l">Total Dues</div></div>
            </div>
        </div>
    </div>
</div>

<!-- ================= EMPLOYEE ================= -->
<div class="rpt-section" id="sec-emp">
    <div class="rpt-head" onclick="toggleSection('sec-emp')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-user-circle"></i> Employee Report</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-emp')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-emp-body">
        <div class="rpt-body-inner">
            <?php if (empty($employees)): ?><div class="empty">No employees</div>
            <?php else: ?>
            <table class="rpt-tbl" data-collapse="10">
                <thead><tr><th>Name</th><th>Role</th><th>Phone</th><th>Salary</th><th>Status</th></tr></thead>
                <tbody>
                <?php foreach ($employees as $e): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($e['employee_name']); ?></td>
                        <td><?php echo htmlspecialchars($e['role'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($e['phone'] ?? ''); ?></td>
                        <td><?php echo money($e['salary'] ?? 0); ?></td>
                        <td><?php echo htmlspecialchars($e['status'] ?? ''); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ================= PRODUCTS PERFORMANCE ================= -->
<div class="rpt-section" id="sec-prodperf">
    <div class="rpt-head" onclick="toggleSection('sec-prodperf')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-chart-line"></i> Products Performance Report</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-prodperf')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-prodperf-body">
        <div class="rpt-body-inner">
            <?php if (empty($prod_perf)): ?><div class="empty">No sales yet</div>
            <?php else: ?>
            <table class="rpt-tbl" data-collapse="10">
                <thead><tr><th>Product</th><th>Qty Sold</th><th>Revenue</th></tr></thead>
                <tbody>
                <?php foreach ($prod_perf as $p): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($p['product_name']); ?></td>
                        <td><?php echo number_format((float)$p['qty_sold'], 2); ?></td>
                        <td><?php echo money($p['revenue']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ================= INVENTORY ================= -->
<div class="rpt-section" id="sec-inv">
    <div class="rpt-head" onclick="toggleSection('sec-inv')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-boxes"></i> Inventory Tracking Report</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-inv')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-inv-body">
        <div class="rpt-body-inner">
            <?php if (empty($inventory)): ?><div class="empty">No products</div>
            <?php else: ?>
            <table class="rpt-tbl" data-collapse="10">
                <thead><tr><th>Product</th><th>Stock</th><th>Unit</th><th>Low</th><th>Price</th></tr></thead>
                <tbody>
                <?php foreach ($inventory as $i): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($i['product_name']); ?></td>
                        <td style="<?php echo ((float)$i['stock_qty'] <= (float)$i['low_stock']) ? 'color:#DC2626;font-weight:700;' : ''; ?>"><?php echo number_format((float)$i['stock_qty'], 2); ?></td>
                        <td><?php echo htmlspecialchars($i['unit'] ?? ''); ?></td>
                        <td><?php echo (float)$i['low_stock']; ?></td>
                        <td><?php echo money($i['price']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ================= PURCHASES ================= -->
<div class="rpt-section" id="sec-purch">
    <div class="rpt-head" onclick="toggleSection('sec-purch')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-clipboard-check"></i> Purchases Report</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-purch')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-purch-body">
        <div class="rpt-body-inner">
            <?php if (empty($purchases)): ?><div class="empty">No purchases</div>
            <?php else: ?>
            <table class="rpt-tbl" data-collapse="10">
                <thead><tr><th>Date</th><th>Supplier</th><th>Product</th><th>Qty</th><th>Total</th><th>Status</th></tr></thead>
                <tbody>
                <?php foreach ($purchases as $p): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($p['purchase_date'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($p['supplier_name'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($p['product_name'] ?? ''); ?></td>
                        <td><?php echo number_format((float)$p['quantity'], 2); ?></td>
                        <td><?php echo money($p['total_amount']); ?></td>
                        <td><?php echo htmlspecialchars($p['payment_status'] ?? ''); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ================= PROFIT & LOSS ================= -->
<div class="rpt-section" id="sec-pl">
    <div class="rpt-head" onclick="toggleSection('sec-pl')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-hand-holding-usd"></i> Profit and Loss Report</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-pl')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-pl-body">
        <div class="rpt-body-inner">
            <div class="rpt-grid">
                <div class="rpt-kpi"><div class="v"><?php echo money($revenue); ?></div><div class="l">Revenue</div></div>
                <div class="rpt-kpi"><div class="v"><?php echo money($cost); ?></div><div class="l">Cost of Goods</div></div>
                <div class="rpt-kpi"><div class="v"><?php echo money($expenses); ?></div><div class="l">Expenses</div></div>
                <div class="rpt-kpi"><div class="v" style="color:<?php echo $pl_profit>=0?'#16A34A':'#DC2626'; ?>;"><?php echo money($pl_profit); ?></div><div class="l">Net Profit</div></div>
            </div>
        </div>
    </div>
</div>

<!-- ================= DUES ================= -->
<div class="rpt-section" id="sec-dues">
    <div class="rpt-head" onclick="toggleSection('sec-dues')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-coins"></i> Dues List Report</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-dues')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-dues-body">
        <div class="rpt-body-inner">
            <?php if (empty($dues)): ?><div class="empty">No dues</div>
            <?php else: ?>
            <table class="rpt-tbl" data-collapse="10">
                <thead><tr><th>Invoice</th><th>Customer</th><th>Phone</th><th>Total</th><th>Paid</th><th>Due</th><th>Date</th></tr></thead>
                <tbody>
                <?php foreach ($dues as $d): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($d['invoice_no'] ?? ('#'.$d['id'])); ?></td>
                        <td><?php echo htmlspecialchars($d['customer_name']); ?></td>
                        <td><?php echo htmlspecialchars($d['phone'] ?? ''); ?></td>
                        <td><?php echo money($d['total_amount']); ?></td>
                        <td><?php echo money($d['amount_received']); ?></td>
                        <td style="color:#DC2626;font-weight:700;"><?php echo money($d['amount_due']); ?></td>
                        <td><?php echo htmlspecialchars(substr($d['created_at'],0,10)); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ================= EXPENSES ================= -->
<div class="rpt-section" id="sec-exp">
    <div class="rpt-head" onclick="toggleSection('sec-exp')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-wallet"></i> Expenses Report</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-exp')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-exp-body">
        <div class="rpt-body-inner">
            <?php if (empty($expenses_list)): ?><div class="empty">No expenses</div>
            <?php else: ?>
            <table class="rpt-tbl" data-collapse="10">
                <thead><tr><th>Date</th><th>Title</th><th>Amount</th><th>Mode</th></tr></thead>
                <tbody>
                <?php foreach ($expenses_list as $x): ?>
                    <tr>
                        <td><?php echo htmlspecialchars(substr($x['created_at'],0,10)); ?></td>
                        <td><?php echo htmlspecialchars($x['title']); ?></td>
                        <td><?php echo money($x['amount']); ?></td>
                        <td><?php echo htmlspecialchars($x['payment_mode'] ?? ''); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ================= CUSTOMERS ================= -->
<div class="rpt-section" id="sec-cust">
    <div class="rpt-head" onclick="toggleSection('sec-cust')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-users"></i> Customers Report</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-cust')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-cust-body">
        <div class="rpt-body-inner">
            <?php if (empty($customers)): ?><div class="empty">No customers</div>
            <?php else: ?>
            <table class="rpt-tbl" data-collapse="10">
                <thead><tr><th>Name</th><th>Phone</th><th>Type</th><th>Due</th></tr></thead>
                <tbody>
                <?php foreach ($customers as $c): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($c['customer_name']); ?></td>
                        <td><?php echo htmlspecialchars($c['phone'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($c['customer_type'] ?? ''); ?></td>
                        <td><?php echo money($c['due_amount'] ?? 0); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ================= SERVICES ================= -->
<div class="rpt-section" id="sec-serv">
    <div class="rpt-head" onclick="toggleSection('sec-serv')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-briefcase"></i> Services Report</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-serv')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-serv-body">
        <div class="rpt-body-inner">
            <?php if (empty($services)): ?><div class="empty">No services</div>
            <?php else: ?>
            <table class="rpt-tbl" data-collapse="10">
                <thead><tr><th>Service</th><th>Category</th><th>Unit</th><th>Cost</th><th>Price</th></tr></thead>
                <tbody>
                <?php foreach ($services as $s): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($s['service_name']); ?></td>
                        <td><?php echo htmlspecialchars($s['category'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($s['unit'] ?? ''); ?></td>
                        <td><?php echo money($s['cost']); ?></td>
                        <td><?php echo money($s['price']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ================= STOCK ================= -->
<div class="rpt-section" id="sec-stock">
    <div class="rpt-head" onclick="toggleSection('sec-stock')">
        <h3><i class="fas fa-chevron-right rpt-chev"></i> <i class="fas fa-warehouse"></i> Stock Report</h3>
        <div class="rpt-actions">
            <button class="rpt-btn" onclick="event.stopPropagation();printSection('sec-stock')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>
    <div class="rpt-body" id="sec-stock-body">
        <div class="rpt-body-inner">
            <?php if (empty($stock)): ?><div class="empty">No stock</div>
            <?php else: ?>
            <div class="rpt-sub">Total Stock Value: <strong><?php echo money($stock_total_value); ?></strong></div>
            <table class="rpt-tbl" data-collapse="10">
                <thead><tr><th>Product</th><th>Qty</th><th>Unit</th><th>Buy</th><th>Sell</th><th>Value</th></tr></thead>
                <tbody>
                <?php foreach ($stock as $s): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($s['product_name']); ?></td>
                        <td><?php echo number_format((float)$s['stock_qty'], 2); ?></td>
                        <td><?php echo htmlspecialchars($s['unit'] ?? ''); ?></td>
                        <td><?php echo money($s['purchase_price']); ?></td>
                        <td><?php echo money($s['price']); ?></td>
                        <td><?php echo money($s['stock_value']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
/* ---------- Toggle a section open/closed ---------- */
function toggleSection(id){
    const head = document.querySelector('#' + id + ' .rpt-head');
    const body = document.getElementById(id + '-body');
    if (!head || !body) return;
    const isOpen = body.classList.contains('open');
    if (isOpen) {
        body.classList.remove('open');
        head.classList.remove('open');
    } else {
        body.classList.add('open');
        head.classList.add('open');
    }
}

/* ---------- Collapse long tables inside a section (show first N rows) ---------- */
document.querySelectorAll('table.rpt-tbl[data-collapse]').forEach(function(tbl){
    const limit = parseInt(tbl.dataset.collapse) || 10;
    const rows = Array.from(tbl.querySelectorAll('tbody tr'));
    if (rows.length <= limit) return;

    rows.forEach((r, i) => { if (i >= limit) r.classList.add('hidden-row'); });

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'rpt-toggle';
    btn.textContent = 'Show all ' + rows.length + ' rows ▼';
    let open = false;

    btn.addEventListener('click', function(e){
        e.stopPropagation();
        open = !open;
        rows.forEach((r, i) => {
            if (i >= limit) r.classList.toggle('hidden-row', !open);
        });
        btn.textContent = open ? 'Show less ▲' : 'Show all ' + rows.length + ' rows ▼';
    });

    tbl.parentNode.appendChild(btn);
});

/* ---------- Print a single section as PDF ---------- */
function printSection(id){
    const el = document.getElementById(id);
    if (!el) return;

    // Ensure section is open
    const body = document.getElementById(id + '-body');
    const head = el.querySelector('.rpt-head');
    if (body) body.classList.add('open');
    if (head) head.classList.add('open');

    // Force all hidden rows visible
    const hidden = el.querySelectorAll('.hidden-row');
    hidden.forEach(r => r.classList.remove('hidden-row'));

    // Print just this section
    document.querySelectorAll('.printing').forEach(e => e.classList.remove('printing'));
    el.classList.add('printing');
    window.print();

    // Restore collapse after print
    setTimeout(function(){
        el.classList.remove('printing');
        const limit = 10;
        document.querySelectorAll('#' + id + ' table.rpt-tbl[data-collapse]').forEach(function(tbl){
            const lim = parseInt(tbl.dataset.collapse) || limit;
            const rows = Array.from(tbl.querySelectorAll('tbody tr'));
            rows.forEach((r, i) => { if (i >= lim) r.classList.add('hidden-row'); });
        });
    }, 400);
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>