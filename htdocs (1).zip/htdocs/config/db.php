<?php
// config/db.php

// =========================================================
// Database Configuration for InfinityFree
// Account: if0_42727461
// Domain:  mwalimushoppingcenter.gt.tc
// Database: if0_42727461_mwalimu_shop
// =========================================================

define('DB_HOST', 'sql201.infinityfree.com');       // MySQL Hostname
define('DB_USER', 'if0_42727461');                  // MySQL Username
define('DB_PASS', 'Mmcenter2026');                  // MySQL Password
define('DB_NAME', 'if0_42727461_mwalimu_shop');     // Your DB

define('DB_CHARSET', 'utf8mb4');

$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::ATTR_TIMEOUT            => 10,
];

try {
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    error_log('DB Connection Failed: ' . $e->getMessage());
    die('Database Connection Failed. Please try again later.');
}