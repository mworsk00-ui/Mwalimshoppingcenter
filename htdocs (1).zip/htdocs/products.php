<?php
$page_title = 'Products';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/flash.php';

// --- Handle Delete (soft delete) ---
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("UPDATE products SET deleted_at = NOW() WHERE id = ?");
        $stmt->execute([$id]);
        flash('success', 'Product moved to Recycle Bin.');
    } catch (PDOException $e) {
        flash('error', 'Could not delete: ' . $e->getMessage());
    }
    header('Location: products.php');
    exit;
}

// --- Handle Hide / Show (toggle status) ---
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    try {
        $st = $pdo->prepare("SELECT product_name, status FROM products WHERE id = ? AND deleted_at IS NULL");
        $st->execute([$id]);
        $row = $st->fetch();
        if ($row) {
            $new = (($row['status'] ?? 'Active') === 'Active') ? 'Inactive' : 'Active';
            $up = $pdo->prepare("UPDATE products SET status = ? WHERE id = ?");
            $up->execute([$new, $id]);
            flash('success', "'{$row['product_name']}' is now {$new}.");
        } else {
            flash('warning', 'Product not found.');
        }
    } catch (PDOException $e) {
        flash('error', 'Could not toggle: ' . $e->getMessage());
    }
    header('Location: products.php');
    exit;
}

require_once __DIR__ . '/includes/header.php';

// --- Search ---
$search = trim($_GET['q'] ?? '');
$products = [];

try {
    if ($search !== '') {
        $like = '%' . $search . '%';
        $stmt = $pdo->prepare("
            SELECT * FROM products
            WHERE deleted_at IS NULL
              AND (product_name LIKE ? OR barcode LIKE ? OR category LIKE ? OR brand LIKE ?)
            ORDER BY id DESC LIMIT 200
        ");
        $stmt->execute([$like, $like, $like, $like]);
        $products = $stmt->fetchAll();
    } else {
        $products = $pdo->query("SELECT * FROM products WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 200")->fetchAll();
    }
} catch (Exception $e) {
    $products = [];
}
?>

<header class="leo-page-header">
    <div class="leo-page-header-left">
        <a href="index.php" class="leo-back-btn"><i class="fas fa-chevron-left"></i></a>
        <span class="leo-page-header-title">Products</span>
    </div>
    <div class="leo-page-header-actions">
        <a href="recycle-bin.php" class="leo-save-btn"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;background:#FEF3C7;color:#92400E;">
            <i class="fas fa-recycle"></i> BIN
        </a>
    </div>
</header>

<form method="get" action="products.php" class="leo-page-search">
    <div class="leo-page-search-bar" style="position:relative;">
        <i class="fas fa-search" style="color:#9CA3AF;"></i>
        <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
               placeholder="Search name, barcode, category, brand..." autofocus>
        <?php if ($search !== ''): ?>
            <a href="products.php" style="color:#9CA3AF;text-decoration:none;padding:0 0.25rem;" title="Clear">
                <i class="fas fa-times-circle"></i>
            </a>
        <?php else: ?>
            <span class="leo-scan"><i class="fas fa-barcode"></i></span>
        <?php endif; ?>
    </div>
</form>

<?php if ($search !== ''): ?>
    <div style="margin:0.4rem 0.85rem;font-size:0.82rem;color:#64748B;">
        Showing <?= count($products) ?> result<?= count($products) === 1 ? '' : 's' ?> for "<strong><?= htmlspecialchars($search) ?></strong>"
    </div>
<?php endif; ?>

<?php if (empty($products)): ?>
    <div class="leo-empty">
        <div class="leo-empty-img"><i class="fas fa-box-open"></i></div>
        <h4><?= $search !== '' ? 'No products match your search' : 'Product list is empty, Add products' ?></h4>
        <p>
            <?php if ($search !== ''): ?>
                Try a different name, or <a href="products.php" style="color:var(--leo-primary);font-weight:600;">clear search</a>.
            <?php else: ?>
                Tap the + button to add your first product
            <?php endif; ?>
        </p>
    </div>
<?php else: ?>

<div class="leo-section-card" style="margin:0 0.85rem;">
    <?php foreach ($products as $p):
        $isActive = ($p['status'] ?? 'Active') === 'Active';
    ?>
    <div class="leo-person-item prod-item" style="<?= $isActive ? '' : 'opacity:0.6;' ?>">
        <a href="product-view.php?id=<?= (int)$p['id'] ?>"
           style="text-decoration:none;color:inherit;display:flex;align-items:center;flex:1;min-width:0;">
            <div class="leo-person-avatar"><i class="fas fa-box"></i></div>
            <div class="leo-person-body" style="min-width:0;">
                <div class="leo-person-name">
                    <?= htmlspecialchars($p['product_name']) ?>
                    <?php if (!$isActive): ?>
                        <span style="font-size:0.65rem;font-weight:700;text-transform:uppercase;background:#FEF3C7;color:#92400E;padding:0.1rem 0.4rem;border-radius:999px;margin-left:0.3rem;">Hidden</span>
                    <?php endif; ?>
                </div>
                <div class="leo-person-sub">Stock: <?= (int)$p['stock_qty'] ?> <?= htmlspecialchars($p['unit'] ?? 'units') ?></div>
            </div>
            <div class="leo-person-value up" style="margin-right:0.5rem;">TSH <?= number_format((float)($p['price'] ?? 0), 0) ?></div>
        </a>

        <button type="button"
                class="prod-manage-btn"
                data-product-id="<?= (int)$p['id'] ?>"
                data-product-name="<?= htmlspecialchars($p['product_name'], ENT_QUOTES) ?>"
                data-product-status="<?= $isActive ? 'Active' : 'Inactive' ?>"
                title="Manage"
                style="flex-shrink:0;display:inline-flex;align-items:center;gap:0.3rem;padding:0.45rem 0.7rem;border-radius:8px;font-size:0.75rem;font-weight:600;background:#F1F5F9;color:#334155;border:1px solid #E2E8F0;cursor:pointer;">
            <i class="fas fa-ellipsis-v"></i>
        </button>
    </div>
    <?php endforeach; ?>
</div>

<!-- Manage bottom sheet -->
<div id="prodSheetBackdrop" class="prod-sheet-backdrop"></div>
<div id="prodSheet" class="prod-sheet" role="dialog" aria-modal="true">
    <div class="prod-sheet-handle"></div>
    <div class="prod-sheet-title" id="prodSheetTitle">Manage product</div>

    <a id="prodSheetEdit" class="prod-sheet-action" href="#">
        <i class="fas fa-pen"></i> <span>Edit product</span>
    </a>
    <a id="prodSheetToggle" class="prod-sheet-action" href="#">
        <i class="fas fa-eye-slash" id="prodSheetToggleIcon"></i> <span id="prodSheetToggleText">Hide</span>
    </a>
    <a id="prodSheetDelete" class="prod-sheet-action prod-sheet-action--danger" href="#">
        <i class="fas fa-trash"></i> <span>Delete</span>
    </a>
    <button type="button" class="prod-sheet-cancel" id="prodSheetCancel">Cancel</button>
</div>

<style>
    /* Row layout tweaks for mobile */
    .prod-item {
        display:flex;
        align-items:center;
        gap:0.5rem;
    }
    @media (max-width: 640px) {
        .prod-item { flex-wrap:nowrap; }
        .leo-person-value { font-size:0.82rem; }
    }

    /* Bottom sheet */
    .prod-sheet-backdrop {
        position:fixed; inset:0;
        background:rgba(15,23,42,0.45);
        opacity:0; pointer-events:none;
        transition:opacity 0.2s ease;
        z-index:1050;
    }
    .prod-sheet-backdrop.open { opacity:1; pointer-events:auto; }

    .prod-sheet {
        position:fixed;
        left:0; right:0; bottom:0;
        background:#fff;
        border-radius:18px 18px 0 0;
        padding:0.8rem 1rem 1rem;
        transform:translateY(110%);
        transition:transform 0.25s ease;
        z-index:1060;
        max-width:520px;
        margin:0 auto;
        box-shadow:0 -6px 24px rgba(0,0,0,0.12);
    }
    .prod-sheet.open { transform:translateY(0); }

    .prod-sheet-handle {
        width:42px;height:5px;border-radius:999px;
        background:#CBD5E1;margin:0 auto 0.7rem;
    }
    .prod-sheet-title {
        font-size:0.95rem;font-weight:700;color:#1E293B;
        margin-bottom:0.7rem;padding:0 0.15rem;
        white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
    }
    .prod-sheet-action {
        display:flex;align-items:center;gap:0.75rem;
        padding:0.85rem 0.9rem;
        border-radius:12px;
        font-size:0.92rem;font-weight:600;
        color:#1E293B;text-decoration:none;
        background:#F8FAFC;
        margin-bottom:0.5rem;
        border:1px solid #EEF2F7;
    }
    .prod-sheet-action i { width:18px;text-align:center;color:#475569; }
    .prod-sheet-action:active { background:#F1F5F9; }
    .prod-sheet-action--danger {
        background:#FEE2E2;color:#991B1B;border-color:#FCA5A5;
    }
    .prod-sheet-action--danger i { color:#991B1B; }

    .prod-sheet-cancel {
        width:100%;
        padding:0.8rem;
        border-radius:12px;
        border:none;
        font-size:0.9rem;font-weight:600;
        background:#F1F5F9;color:#334155;
        cursor:pointer;
        margin-top:0.3rem;
    }
</style>

<script>
(function() {
    const backdrop  = document.getElementById('prodSheetBackdrop');
    const sheet     = document.getElementById('prodSheet');
    const titleEl   = document.getElementById('prodSheetTitle');
    const editLink  = document.getElementById('prodSheetEdit');
    const toggleLink= document.getElementById('prodSheetToggle');
    const toggleIcon= document.getElementById('prodSheetToggleIcon');
    const toggleTxt = document.getElementById('prodSheetToggleText');
    const deleteLink= document.getElementById('prodSheetDelete');
    const cancelBtn = document.getElementById('prodSheetCancel');

    let currentName = '';

    function openSheet(data) {
        currentName = data.name;
        titleEl.textContent = data.name;

        editLink.href = 'product-edit.php?id=' + data.id;

        toggleLink.href = 'products.php?toggle=' + data.id;
        if (data.status === 'Active') {
            toggleIcon.className = 'fas fa-eye-slash';
            toggleTxt.textContent = 'Hide product';
        } else {
            toggleIcon.className = 'fas fa-eye';
            toggleTxt.textContent = 'Show product';
        }

        deleteLink.href = '#';
        deleteLink.dataset.id = data.id;
        deleteLink.dataset.name = data.name;

        backdrop.classList.add('open');
        sheet.classList.add('open');
        document.body.style.overflow = 'hidden';
    }

    function closeSheet() {
        backdrop.classList.remove('open');
        sheet.classList.remove('open');
        document.body.style.overflow = '';
    }

    document.querySelectorAll('.prod-manage-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            openSheet({
                id: btn.dataset.productId,
                name: btn.dataset.productName,
                status: btn.dataset.productStatus
            });
        });
    });

    backdrop.addEventListener('click', closeSheet);
    cancelBtn.addEventListener('click', closeSheet);

    // Swipe-down on handle to close
    let startY = null;
    sheet.addEventListener('touchstart', function(e) {
        if (e.target.closest('.prod-sheet-handle') || e.target === sheet) {
            startY = e.touches[0].clientY;
        }
    });
    sheet.addEventListener('touchmove', function(e) {
        if (startY === null) return;
        const dy = e.touches[0].clientY - startY;
        if (dy > 60) { closeSheet(); startY = null; }
    });
    sheet.addEventListener('touchend', function() { startY = null; });

    // Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeSheet();
    });

    // Delete confirmation
    deleteLink.addEventListener('click', function(e) {
        e.preventDefault();
        const id = deleteLink.dataset.id;
        const name = deleteLink.dataset.name;
        const msg = "Move '" + name + "' to the Recycle Bin? You can restore it later.";

        // Use your existing confirm helper if available, else native confirm
        if (typeof window.leoConfirm === 'function') {
            window.leoConfirm(msg, function() {
                window.location.href = 'products.php?delete=' + id;
            });
        } else if (confirm(msg)) {
            window.location.href = 'products.php?delete=' + id;
        }
    });
})();
</script>

<?php endif; ?>

<a href="product-add.php" class="leo-fab"><i class="fas fa-plus"></i></a>

<?php require_once __DIR__ . '/includes/footer.php'; ?>