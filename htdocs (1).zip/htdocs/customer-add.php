<?php
$page_title = 'Add Customer';
require_once __DIR__ . '/config/db.php';

$edit_id = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$customer = [
    'customer_name' => '',
    'phone'         => '',
    'customer_type' => 'End Customer (Retailer)',
    'email'         => '',
    'tin'           => '',
    'address'       => '',
    'due'           => 0,
];

if ($edit_id) {
    try {
        $st = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
        $st->execute([$edit_id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if ($row) $customer = array_merge($customer, $row);
    } catch (Exception $e) {}
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['customer_name'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $type    = trim($_POST['customer_type'] ?? 'End Customer (Retailer)');
    $email   = trim($_POST['email'] ?? '');
    $tin     = trim($_POST['tin'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $due     = floatval($_POST['due'] ?? 0);
    $id      = (int)($_POST['id'] ?? 0);

    if ($name !== '') {
        try {
            if ($id) {
                $stmt = $pdo->prepare("UPDATE customers SET
                    customer_name=?, phone=?, customer_type=?, email=?, tin=?, address=?, due=?
                    WHERE id=?");
                $stmt->execute([$name,$phone,$type,$email,$tin,$address,$due,$id]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO customers
                    (customer_name, phone, customer_type, email, tin, address, due)
                    VALUES (?,?,?,?,?,?,?)");
                $stmt->execute([$name,$phone,$type,$email,$tin,$address,$due]);
            }
            header('Location: customers.php');
            exit;
        } catch (Exception $e) {
            try {
                if ($id) {
                    $stmt = $pdo->prepare("UPDATE customers SET customer_name=?, phone=? WHERE id=?");
                    $stmt->execute([$name,$phone,$id]);
                } else {
                    $stmt = $pdo->prepare("INSERT INTO customers (customer_name, phone) VALUES (?,?)");
                    $stmt->execute([$name,$phone]);
                }
                header('Location: customers.php');
                exit;
            } catch (Exception $e2) {}
        }
    }
}
require_once __DIR__ . '/includes/header.php';
?>
<header class="leo-page-header">
    <div class="leo-page-header-left">
        <a href="customers.php" class="leo-back-btn"><i class="fas fa-chevron-left"></i></a>
        <span class="leo-page-header-title"><?php echo $edit_id ? 'Edit Customer' : 'Please Add a Customer'; ?></span>
    </div>
</header>

<form method="post" id="custForm" class="leo-form-card" style="margin:0.85rem;">
    <input type="hidden" name="id" value="<?php echo (int)$edit_id; ?>">
    <div class="leo-form-card-body">

        <div class="leo-form-row">
            <label class="leo-input-label">Name</label>
            <div class="leo-input-row">
                <input type="text" name="customer_name" class="leo-input" placeholder="Enter customer name"
                       value="<?php echo htmlspecialchars($customer['customer_name']); ?>" required>
                <span class="leo-input-row-icon"><i class="fas fa-address-card"></i></span>
            </div>
        </div>

        <div style="text-align:center;margin:1rem 0;">
            <div style="width:100px;height:100px;border-radius:14px;background:var(--leo-blue-soft);display:inline-flex;align-items:center;justify-content:center;color:var(--leo-primary);font-size:2.5rem;">
                <i class="fas fa-user"></i>
            </div>
        </div>

        <div class="leo-form-row">
            <label class="leo-input-label">Phone Number</label>
            <input type="tel" name="phone" class="leo-input" placeholder="Enter your phone number"
                   value="<?php echo htmlspecialchars($customer['phone']); ?>"
                   style="border:0;border-bottom:1px solid #E5EAF0;border-radius:0;padding-left:0;">
        </div>

        <div class="leo-form-row">
            <?php
            $types = ['End Customer (Retailer)', 'Wholesaler', 'Dealer'];
            foreach ($types as $t):
                $isSel = ($customer['customer_type'] === $t);
            ?>
            <label class="leo-form-radio-row">
                <input type="radio" name="customer_type" value="<?php echo htmlspecialchars($t); ?>"
                       <?php echo $isSel ? 'checked' : ''; ?> style="display:none;">
                <span class="leo-form-radio <?php echo $isSel ? 'checked' : ''; ?>"></span>
                <span class="leo-form-radio-label"><?php echo htmlspecialchars($t); ?></span>
            </label>
            <?php endforeach; ?>
        </div>

        <div class="leo-form-row">
            <label class="leo-input-label">Email Address</label>
            <input type="email" name="email" class="leo-input" placeholder="Enter email address"
                   value="<?php echo htmlspecialchars($customer['email']); ?>"
                   style="border:0;border-bottom:1px solid #E5EAF0;border-radius:0;padding-left:0;">
        </div>

        <div class="leo-form-row">
            <label class="leo-input-label">Taxpayer Identification Number</label>
            <input type="text" name="tin" class="leo-input" placeholder="Enter taxpayer identification number"
                   value="<?php echo htmlspecialchars($customer['tin']); ?>"
                   style="border:0;border-bottom:1px solid #E5EAF0;border-radius:0;padding-left:0;">
        </div>

        <div class="leo-form-row">
            <label class="leo-input-label">Address</label>
            <input type="text" name="address" class="leo-input" placeholder="Enter personal address"
                   value="<?php echo htmlspecialchars($customer['address']); ?>"
                   style="border:0;border-bottom:1px solid #E5EAF0;border-radius:0;padding-left:0;">
        </div>

        <div class="leo-form-row">
            <label class="leo-input-label">Previous Due</label>
            <div style="display:flex;align-items:center;gap:0.5rem;">
                <input type="number" name="due" class="leo-input" placeholder="Amount"
                       value="<?php echo htmlspecialchars($customer['due']); ?>"
                       style="border:0;border-bottom:1px solid #E5EAF0;border-radius:0;padding-left:0;">
                <span style="font-size:0.75rem;color:var(--leo-muted);text-align:right;">Customer<br>Signature</span>
            </div>
        </div>
    </div>

    <!-- SAVE / CANCEL inside the card, right-aligned -->
    <div style="display:flex;justify-content:flex-end;gap:0.6rem;padding:0.85rem;border-top:1px solid #EEF1F5;">
        <a href="customers.php" class="leo-btn leo-btn--outline">CANCEL</a>
        <button type="submit" class="leo-btn leo-btn--primary">
            <?php echo $edit_id ? 'UPDATE' : 'SAVE'; ?>
        </button>
    </div>
</form>

<script>
document.querySelectorAll('.leo-form-radio-row').forEach(function(row){
    row.addEventListener('click', function(){
        document.querySelectorAll('.leo-form-radio-row').forEach(function(r){
            r.querySelector('input[type="radio"]').checked = false;
            r.querySelector('.leo-form-radio').classList.remove('checked');
        });
        this.querySelector('input[type="radio"]').checked = true;
        this.querySelector('.leo-form-radio').classList.add('checked');
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>