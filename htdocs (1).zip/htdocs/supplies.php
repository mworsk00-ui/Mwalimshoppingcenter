<?php
$page_title = 'Supplies';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/flash.php';

// Soft delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("UPDATE supplies SET deleted_at = NOW() WHERE id = ?");
        $stmt->execute([$id]);
        flash('success', 'Supply record moved to Recycle Bin. You can restore it from there.');
    } catch (PDOException $e) {
        flash('error', 'Could not delete supply: ' . $e->getMessage());
    }
    header('Location: supplies.php');
    exit;
}

// Filters + search
$filter_status = $_GET['status'] ?? '';
$filter_cust   = (int)($_GET['customer'] ?? 0);
$search        = trim($_GET['q'] ?? '');

$sql = "SELECT s.* FROM supplies s WHERE s.deleted_at IS NULL";
$params = [];

if ($filter_status !== '') {
    $sql .= " AND s.payment_status = ?";
    $params[] = $filter_status;
}
if ($filter_cust > 0) {
    $sql .= " AND s.customer_id = ?";
    $params[] = $filter_cust;
}
if ($search !== '') {
    $like = '%' . $search . '%';
    $sql .= " AND (s.customer_name LIKE ? OR s.product_name LIKE ?)";
    $params[] = $like;
    $params[] = $like;
}

$sql .= " ORDER BY s.supply_date DESC, s.id DESC LIMIT 200";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$supplies = $stmt->fetchAll();

// Auto-jump: if search returned exactly 1 result, go straight to view
if ($search !== '' && count($supplies) === 1) {
    header('Location: supply-view.php?id=' . (int)$supplies[0]['id']);
    exit;
}

// Customers list for filter
$customers = $pdo->query("SELECT id, customer_name FROM customers WHERE deleted_at IS NULL ORDER BY customer_name")->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<header class="leo-page-header">
    <div class="leo-page-header-left">
        <a href="index.php" class="leo-back-btn"><i class="fas fa-chevron-left"></i></a>
        <span class="leo-page-header-title">Supplies</span>
    </div>
    <div class="leo-page-header-actions">
        <a href="recycle-bin.php" class="leo-save-btn"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;background:#FEF3C7;color:#92400E;margin-right:0.4rem;">
            <i class="fas fa-recycle"></i> BIN
        </a>
        <a href="supply-guide.php" class="leo-save-btn"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;background:#FEF3C7;color:#92400E;margin-right:0.4rem;">
            <i class="fas fa-circle-question"></i> GUIDE
        </a>
        <a href="supply-add.php" class="leo-save-btn"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;">
            <i class="fas fa-plus"></i> ADD
        </a>
    </div>
</header>

<!-- Search bar -->
<div style="margin:0.85rem 0.85rem 0;">
    <form method="get" action="supplies.php" style="display:flex;gap:0.5rem;align-items:center;">
        <input type="hidden" name="status" value="<?= htmlspecialchars($filter_status) ?>">
        <input type="hidden" name="customer" value="<?= (int)$filter_cust ?>">
        <div style="position:relative;flex:1;">
            <i class="fas fa-search" style="position:absolute;left:0.9rem;top:50%;transform:translateY(-50%);color:#94A3B8;font-size:0.85rem;pointer-events:none;"></i>
            <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
                   placeholder="Search by customer or product..."
                   autofocus
                   style="width:100%;padding:0.7rem 2.4rem 0.7rem 2.4rem;border:1px solid #E2E8F0;border-radius:10px;font-size:0.9rem;background:#fff;color:#1E293B;outline:none;">
            <?php if ($search !== ''): ?>
                <a href="supplies.php?status=<?= urlencode($filter_status) ?>&customer=<?= (int)$filter_cust ?>"
                   style="position:absolute;right:0.7rem;top:50%;transform:translateY(-50%);color:#94A3B8;font-size:0.9rem;text-decoration:none;"
                   title="Clear search">
                    <i class="fas fa-times-circle"></i>
                </a>
            <?php endif; ?>
        </div>
        <button type="submit"
                style="padding:0.7rem 1.1rem;border:none;border-radius:10px;font-size:0.85rem;font-weight:600;background:var(--leo-primary);color:#fff;cursor:pointer;display:inline-flex;align-items:center;gap:0.4rem;">
            <i class="fas fa-search"></i> <span class="search-btn-text">Search</span>
        </button>
    </form>
    <?php if ($search !== ''): ?>
        <div style="margin-top:0.5rem;font-size:0.82rem;color:var(--leo-muted);">
            Showing <?= count($supplies) ?> result<?= count($supplies) === 1 ? '' : 's' ?> for "<strong><?= htmlspecialchars($search) ?></strong>"
        </div>
    <?php endif; ?>
</div>

<!-- Filters -->
<form method="get" class="leo-form-card" style="margin:0.85rem;padding:0.85rem;display:flex;flex-wrap:wrap;gap:0.6rem;align-items:end;">
    <input type="hidden" name="q" value="<?= htmlspecialchars($search) ?>">
    <div style="flex:1;min-width:140px;">
        <label class="leo-input-label" style="font-size:0.8rem;">Customer</label>
        <select name="customer" class="leo-input" style="width:100%;">
            <option value="0">All customers</option>
            <?php foreach ($customers as $c): ?>
                <option value="<?= (int)$c['id'] ?>" <?= $filter_cust === (int)$c['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($c['customer_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div style="flex:1;min-width:120px;">
        <label class="leo-input-label" style="font-size:0.8rem;">Payment Status</label>
        <select name="status" class="leo-input" style="width:100%;">
            <option value="">All statuses</option>
            <option value="Paid"    <?= $filter_status === 'Paid'    ? 'selected' : '' ?>>Paid</option>
            <option value="Partial" <?= $filter_status === 'Partial' ? 'selected' : '' ?>>Partial</option>
            <option value="Unpaid"  <?= $filter_status === 'Unpaid'  ? 'selected' : '' ?>>Unpaid</option>
        </select>
    </div>
    <button type="submit" class="leo-btn leo-btn--primary" style="padding:0.65rem 1rem;">
        <i class="fas fa-filter"></i> Filter
    </button>
    <a href="supplies.php" class="leo-btn leo-btn--outline" style="padding:0.65rem 1rem;">Reset</a>
</form>

<div class="leo-form-card" style="margin:0.85rem;padding:0;overflow:hidden;">
    <style>
        .sup-table { width:100%; border-collapse:collapse; }
        .sup-table thead th {
            text-align:left; padding:0.9rem 0.7rem; font-size:0.75rem;
            text-transform:uppercase; color:var(--leo-primary);
            background:var(--leo-blue-soft);
        }
        .sup-table tbody tr { border-top:1px solid #EEF2F7; }

        @media (max-width: 640px) {
            .sup-table thead { display:none; }
            .sup-table, .sup-table tbody, .sup-table tr, .sup-table td {
                display:block; width:100%;
            }
            .sup-table tr {
                padding:0.9rem 1rem;
                border-top:1px solid #EEF2F7;
            }
            .sup-table td {
                padding:0.25rem 0 !important;
                border:none !important;
                text-align:left !important;
            }
            .sup-table td[data-label]::before {
                content: attr(data-label) ": ";
                font-weight:700;
                color:var(--leo-primary);
                font-size:0.78rem;
                text-transform:uppercase;
                margin-right:0.4rem;
            }
            .sup-table td.sup-actions {
                text-align:left !important;
                margin-top:0.6rem;
                white-space:normal !important;
            }
            .sup-table td.sup-actions a {
                margin-bottom:0.35rem;
            }
            .search-btn-text { display:none; }
        }
    </style>

    <table class="sup-table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Customer</th>
                <th>Product</th>
                <th>Qty</th>
                <th style="text-align:right;">Total</th>
                <th style="text-align:center;">Status</th>
                <th style="text-align:right;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($supplies) > 0): ?>
                <?php foreach ($supplies as $sp):
                    $statusColor = [
                        'Paid'    => '#DCFCE7;color:#166534;border:1px solid #86EFAC',
                        'Partial' => '#FEF3C7;color:#92400E;border:1px solid #FDE68A',
                        'Unpaid'  => '#FEE2E2;color:#991B1B;border:1px solid #FCA5A5',
                    ][$sp['payment_status']] ?? '#E0F2FE;color:#0369A1;border:1px solid #BAE6FD';
                ?>
                    <tr>
                        <td data-label="Date" style="padding:0.85rem 0.7rem;font-size:0.85rem;color:#475569;">
                            <?= htmlspecialchars(date('d M Y', strtotime($sp['supply_date']))) ?>
                        </td>
                        <td data-label="Customer" style="padding:0.85rem 0.7rem;font-size:0.9rem;font-weight:600;color:#1E293B;">
                            <?= htmlspecialchars($sp['customer_name']) ?>
                        </td>
                        <td data-label="Product" style="padding:0.85rem 0.7rem;font-size:0.88rem;color:#334155;">
                            <?= htmlspecialchars($sp['product_name']) ?>
                        </td>
                        <td data-label="Qty" style="padding:0.85rem 0.7rem;font-size:0.85rem;color:#475569;">
                            <?= (float)$sp['quantity'] ?> <?= htmlspecialchars($sp['unit']) ?>
                        </td>
                        <td data-label="Total" style="padding:0.85rem 0.7rem;font-size:0.88rem;font-weight:600;color:#1E293B;text-align:right;">
                            <?= number_format((float)$sp['total_amount'], 2) ?>
                        </td>
                        <td data-label="Status" style="padding:0.85rem 0.7rem;text-align:center;">
                            <span style="display:inline-block;padding:0.2rem 0.6rem;border-radius:999px;font-size:0.68rem;font-weight:700;background:<?= $statusColor ?>;">
                                <?= htmlspecialchars($sp['payment_status']) ?>
                            </span>
                        </td>
                        <td class="sup-actions" style="padding:0.85rem 0.7rem;text-align:right;white-space:nowrap;">
                            <a href="supply-view.php?id=<?= (int)$sp['id'] ?>"
                               style="display:inline-flex;align-items:center;gap:0.3rem;padding:0.4rem 0.6rem;border-radius:8px;font-size:0.75rem;font-weight:600;background:#E0F2FE;color:#0369A1;text-decoration:none;margin-right:0.25rem;">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="supply-edit.php?id=<?= (int)$sp['id'] ?>"
                               style="display:inline-flex;align-items:center;gap:0.3rem;padding:0.4rem 0.6rem;border-radius:8px;font-size:0.75rem;font-weight:600;background:var(--leo-blue-soft);color:var(--leo-primary);text-decoration:none;margin-right:0.25rem;">
                                <i class="fas fa-pen"></i>
                            </a>
                            <a href="supplies.php?delete=<?= (int)$sp['id'] ?>"
                               data-confirm="Move this supply to the Recycle Bin? You can restore it later."
                               data-confirm-ok="Yes, move to bin"
                               data-confirm-cancel="Cancel"
                               style="display:inline-flex;align-items:center;gap:0.3rem;padding:0.4rem 0.6rem;border-radius:8px;font-size:0.75rem;font-weight:600;background:#FEE2E2;color:#991B1B;text-decoration:none;">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" style="text-align:center;padding:2.5rem 1rem;color:var(--leo-muted);font-size:0.9rem;">
                        <i class="fas fa-box-open" style="font-size:1.8rem;display:block;margin-bottom:0.6rem;opacity:0.5;"></i>
                        <?php if ($search !== '' || $filter_status !== '' || $filter_cust > 0): ?>
                            No supply records match your search/filters.
                            <a href="supplies.php" style="color:var(--leo-primary);font-weight:600;">Reset all</a>
                        <?php else: ?>
                            No supply records yet. Click <strong>ADD</strong> to create one.
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>