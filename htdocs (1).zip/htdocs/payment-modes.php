<?php
$page_title = 'Modes of Payment';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/flash.php';

// Handle Delete (SOFT delete -> Recycle Bin)
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("UPDATE payment_modes SET deleted_at = NOW() WHERE id = ?");
        $stmt->execute([$id]);
        flash('success', 'Payment mode moved to Recycle Bin. You can restore it from there.');
    } catch (PDOException $e) {
        flash('error', 'Could not delete payment mode: ' . $e->getMessage());
    }
    header('Location: payment-modes.php');
    exit;
}

// Search
$search = trim($_GET['q'] ?? '');
$payment_modes = [];

if ($search !== '') {
    $like = '%' . $search . '%';
    $stmt = $pdo->prepare("SELECT * FROM payment_modes WHERE deleted_at IS NULL AND (name LIKE ? OR description LIKE ?) ORDER BY name ASC LIMIT 50");
    $stmt->execute([$like, $like]);
    $payment_modes = $stmt->fetchAll();
} else {
    $payment_modes = $pdo->query("SELECT * FROM payment_modes WHERE deleted_at IS NULL ORDER BY id DESC")->fetchAll();
}

// Auto-jump: if search returned exactly 1 result, redirect to edit page
if ($search !== '' && count($payment_modes) === 1) {
    header('Location: payment-mode-edit.php?id=' . (int)$payment_modes[0]['id']);
    exit;
}

require_once __DIR__ . '/includes/header.php';
?>

<header class="leo-page-header">
    <div class="leo-page-header-left">
        <a href="index.php" class="leo-back-btn"><i class="fas fa-chevron-left"></i></a>
        <span class="leo-page-header-title">Modes of Payment</span>
    </div>
    <div class="leo-page-header-actions">
        <a href="recycle-bin.php" class="leo-save-btn"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;background:#FEF3C7;color:#92400E;margin-right:0.4rem;">
            <i class="fas fa-recycle"></i> BIN
        </a>
        <a href="payment-mode-guide.php" class="leo-save-btn"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;background:#FEF3C7;color:#92400E;margin-right:0.4rem;">
            <i class="fas fa-circle-question"></i> GUIDE
        </a>
        <a href="payment-mode-add.php" class="leo-save-btn"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;">
            <i class="fas fa-plus"></i> ADD
        </a>
    </div>
</header>

<!-- Search bar -->
<div style="margin:0.85rem 0.85rem 0;">
    <form method="get" action="payment-modes.php" style="display:flex;gap:0.5rem;align-items:center;">
        <div style="position:relative;flex:1;">
            <i class="fas fa-search" style="position:absolute;left:0.9rem;top:50%;transform:translateY(-50%);color:#94A3B8;font-size:0.85rem;pointer-events:none;"></i>
            <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
                   placeholder="Search by name or description..."
                   autofocus
                   style="width:100%;padding:0.7rem 2.4rem 0.7rem 2.4rem;border:1px solid #E2E8F0;border-radius:10px;font-size:0.9rem;background:#fff;color:#1E293B;outline:none;">
            <?php if ($search !== ''): ?>
                <a href="payment-modes.php"
                   style="position:absolute;right:0.7rem;top:50%;transform:translateY(-50%);color:#94A3B8;font-size:0.9rem;text-decoration:none;"
                   title="Clear search">
                    <i class="fas fa-times-circle"></i>
                </a>
            <?php endif; ?>
        </div>
        <button type="submit"
                style="padding:0.7rem 1.1rem;border:none;border-radius:10px;font-size:0.85rem;font-weight:600;background:var(--leo-primary);color:#fff;cursor:pointer;display:inline-flex;align-items:center;gap:0.4rem;">
            <i class="fas fa-search"></i> <span class="search-btn-text">Search</span>
        </button>
    </form>
    <?php if ($search !== ''): ?>
        <div style="margin-top:0.5rem;font-size:0.82rem;color:var(--leo-muted);">
            Showing <?= count($payment_modes) ?> result<?= count($payment_modes) === 1 ? '' : 's' ?> for "<strong><?= htmlspecialchars($search) ?></strong>"
        </div>
    <?php endif; ?>
</div>

<div class="leo-form-card" style="margin:0.85rem;padding:0;overflow:hidden;">
    <style>
        .pm-table { width:100%; border-collapse:collapse; }
        .pm-table thead th {
            text-align:left; padding:0.9rem 1rem; font-size:0.8rem;
            text-transform:uppercase; color:var(--leo-primary);
            letter-spacing:0.04em; background:var(--leo-blue-soft);
        }
        .pm-table tbody tr { border-top:1px solid #EEF2F7; }

        @media (max-width: 640px) {
            .pm-table thead { display:none; }
            .pm-table, .pm-table tbody, .pm-table tr, .pm-table td {
                display:block; width:100%;
            }
            .pm-table tr {
                padding:0.9rem 1rem;
                border-top:1px solid #EEF2F7;
            }
            .pm-table td {
                padding:0.25rem 0 !important;
                border:none !important;
            }
            .pm-table td[data-label]::before {
                content: attr(data-label) ": ";
                font-weight:700;
                color:var(--leo-primary);
                font-size:0.78rem;
                text-transform:uppercase;
                margin-right:0.4rem;
            }
            .pm-table td.pm-actions {
                text-align:left !important;
                margin-top:0.6rem;
                white-space:normal !important;
            }
            .search-btn-text { display:none; }
        }
    </style>

    <table class="pm-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Description</th>
                <th>Status</th>
                <th style="text-align:right;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($payment_modes) > 0): ?>
                <?php foreach ($payment_modes as $i => $mode): ?>
                    <tr>
                        <td data-label="#" style="padding:1rem;font-size:0.9rem;color:var(--leo-muted);"><?= $i + 1 ?></td>
                        <td data-label="Name" style="padding:1rem;font-size:0.95rem;font-weight:600;color:#1E293B;">
                            <a href="payment-mode-edit.php?id=<?= (int)$mode['id'] ?>" style="color:#1E293B;text-decoration:none;">
                                <?= htmlspecialchars($mode['name']) ?>
                            </a>
                        </td>
                        <td data-label="Description" style="padding:1rem;font-size:0.9rem;color:#475569;">
                            <?= htmlspecialchars($mode['description'] ?? '—') ?>
                        </td>
                        <td data-label="Status" style="padding:1rem;">
                            <span style="display:inline-block;padding:0.25rem 0.7rem;border-radius:999px;font-size:0.72rem;font-weight:700;text-transform:uppercase;background:#FEF3C7;color:#92400E;border:1px solid #FDE68A;">
                                <?= htmlspecialchars($mode['status'] ?? 'Active') ?>
                            </span>
                        </td>
                        <td class="pm-actions" style="padding:1rem;text-align:right;white-space:nowrap;">
                            <a href="payment-mode-edit.php?id=<?= (int)$mode['id'] ?>"
                               style="display:inline-flex;align-items:center;gap:0.35rem;padding:0.45rem 0.8rem;border-radius:8px;font-size:0.8rem;font-weight:600;background:var(--leo-blue-soft);color:var(--leo-primary);text-decoration:none;margin-right:0.35rem;">
                                <i class="fas fa-pen"></i> Edit
                            </a>
                            <a href="payment-modes.php?delete=<?= (int)$mode['id'] ?>"
                               data-confirm="Move '<?= htmlspecialchars($mode['name'], ENT_QUOTES) ?>' to the Recycle Bin? You can restore it later."
                               data-confirm-ok="Yes, move to bin"
                               data-confirm-cancel="Cancel"
                               style="display:inline-flex;align-items:center;gap:0.35rem;padding:0.45rem 0.8rem;border-radius:8px;font-size:0.8rem;font-weight:600;background:#FEE2E2;color:#991B1B;text-decoration:none;">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align:center;padding:2.5rem 1rem;color:var(--leo-muted);font-size:0.9rem;">
                        <i class="fas fa-inbox" style="font-size:1.8rem;display:block;margin-bottom:0.6rem;opacity:0.5;"></i>
                        <?php if ($search !== ''): ?>
                            No payment modes match "<strong><?= htmlspecialchars($search) ?></strong>".
                            <a href="payment-modes.php" style="color:var(--leo-primary);font-weight:600;">Clear search</a>
                        <?php else: ?>
                            No payment modes added yet. Click <strong>ADD</strong> to create one.
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>