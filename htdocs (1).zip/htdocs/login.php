<?php
/**
 * login.php
 * Public login page — Green theme.
 * On success: sets session and redirects to the originally requested page.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/config/db.php';

/* Already logged in? → go home (or to stored redirect) */
if (!empty($_SESSION['user_id'])) {
    $target = $_SESSION['redirect_after_login'] ?? 'index.php';
    unset($_SESSION['redirect_after_login']);
    header('Location: ' . $target);
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Tafadhali jaza sehemu zote.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {

                /* ---- Set session ---- */
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['username']  = $user['username'];
                $_SESSION['full_name'] = $user['full_name'] ?? $user['username'];
                $_SESSION['role']      = $user['role'] ?? 'admin';

                /* ---- Redirect to originally requested page ---- */
                $target = $_SESSION['redirect_after_login'] ?? 'index.php';
                unset($_SESSION['redirect_after_login']);

                /* Safety: never redirect to login.php itself */
                if (strpos($target, 'login.php') !== false) {
                    $target = 'index.php';
                }

                header('Location: ' . $target);
                exit;

            } else {
                $error = 'Username au password si sahihi.';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#16A34A">
    <title>Login | Mwalim Shop</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/leo-style.css">

    <!-- Show/hide password toggle styles -->
    <style>
        .leo-pass-wrap {
            position: relative;
            display: flex;
            align-items: center;
        }
        .leo-pass-wrap .leo-input {
            padding-right: 2.75rem;
            width: 100%;
        }
        .leo-pass-toggle {
            position: absolute;
            right: 0.5rem;
            top: 50%;
            transform: translateY(-50%);
            width: 38px;
            height: 38px;
            border-radius: 8px;
            background: transparent;
            border: none;
            color: #6B7280;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.95rem;
            transition: background 0.15s ease, color 0.15s ease;
        }
        .leo-pass-toggle:hover,
        .leo-pass-toggle:focus {
            background: #F0FDF4;
            color: #16A34A;
            outline: none;
        }
        .leo-pass-toggle:active {
            transform: translateY(-50%) scale(0.94);
        }
    </style>
</head>
<body>

<div class="leo-login-page">
    <div class="leo-login-logo"><i class="fas fa-store"></i></div>
    <div class="leo-login-title">Mwalim Shop</div>
    <div class="leo-login-sub">Business Management System</div>

    <form method="post" class="leo-login-card" autocomplete="off">
        <?php if ($error): ?>
            <div style="background:#FEE2E2;color:#991B1B;padding:0.7rem 0.9rem;border-radius:10px;font-size:0.85rem;margin-bottom:1rem;">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <div class="leo-form-row">
            <label class="leo-input-label" for="username">Username</label>
            <input type="text" id="username" name="username" class="leo-input"
                   placeholder="Enter username" required autofocus autocomplete="username">
        </div>

        <div class="leo-form-row">
            <label class="leo-input-label" for="password">Password</label>
            <div class="leo-pass-wrap">
                <input type="password" id="password" name="password" class="leo-input"
                       placeholder="Enter password" required autocomplete="current-password">
                <button type="button" class="leo-pass-toggle" id="passToggle"
                        aria-label="Show password" aria-pressed="false" tabindex="-1">
                    <i class="fas fa-eye" id="passToggleIcon"></i>
                </button>
            </div>
        </div>

        <button type="submit" class="leo-btn leo-btn--primary leo-btn--block" style="margin-top:0.5rem;">
            <i class="fas fa-sign-in-alt"></i> LOGIN
        </button>

        <p style="text-align:center;font-size:0.75rem;color:#9CA3AF;margin-top:1rem;">

        </p>
    </form>
</div>

<script>
(function () {
    'use strict';

    var input = document.getElementById('password');
    var btn   = document.getElementById('passToggle');
    var icon  = document.getElementById('passToggleIcon');

    if (!input || !btn || !icon) return;

    btn.addEventListener('click', function () {
        var isHidden = input.type === 'password';

        // Toggle visibility
        input.type = isHidden ? 'text' : 'password';

        // Swap icon
        icon.classList.toggle('fa-eye', !isHidden);
        icon.classList.toggle('fa-eye-slash', isHidden);

        // Update aria state
        btn.setAttribute('aria-pressed', isHidden ? 'true' : 'false');
        btn.setAttribute('aria-label', isHidden ? 'Hide password' : 'Show password');

        // Keep focus in the input so typing continues naturally
        input.focus();
        var v = input.value;
        input.value = '';
        input.value = v;
    });

    // Bonus: pressing Esc while visible hides again
    input.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && input.type === 'text') {
            input.type = 'password';
            icon.classList.add('fa-eye');
            icon.classList.remove('fa-eye-slash');
            btn.setAttribute('aria-pressed', 'false');
            btn.setAttribute('aria-label', 'Show password');
        }
    });
})();
</script>

</body>
</html>