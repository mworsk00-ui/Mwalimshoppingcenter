<?php
/**
 * includes/auth.php
 * Global authentication guard.
 *
 * RULE:  This file MUST be the very first require on every protected page.
 *
 *   <?php
 *   require_once __DIR__ . '/includes/auth.php';
 *
 * Behavior:
 *   - Starts the session once.
 *   - If the current page is public (login.php, logout.php) → allow.
 *   - If $_SESSION['user_id'] is missing → redirect to login.php and exit.
 *   - Remembers the originally requested URL so login.php can send the user back.
 *   - Prevents redirect loops.
 */

/* ---- 1. Start the session exactly once ---- */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ---- 2. Pages that do NOT require authentication ---- */
$AUTH_PUBLIC = ['login.php', 'logout.php'];

/* ---- 3. Current page basename (e.g. "index.php") ---- */
$__auth_current = basename($_SERVER['PHP_SELF'] ?? '');

/* ---- 4. Am I logged in? ---- */
$__auth_logged_in = !empty($_SESSION['user_id']);

/* ---- 5. Public page? → do nothing, let it render ---- */
if (in_array($__auth_current, $AUTH_PUBLIC, true)) {
    return;
}

/* ---- 6. Not logged in? → remember target + redirect + exit ---- */
if (!$__auth_logged_in) {

    /* Prevent redirect loop: don't try to "redirect to login" from login */
    if ($__auth_current !== 'login.php') {

        /* Only store the target if it's not already set (first attempt wins) */
        if (empty($_SESSION['redirect_after_login'])) {
            $req = $_SERVER['REQUEST_URI'] ?? '';
            /* Only store relative paths, ignore full URLs */
            if ($req !== '' && strpos($req, 'login.php') === false) {
                $_SESSION['redirect_after_login'] = $req;
            }
        }

        /* Send to login */
        header('Location: login.php');
        exit;
    }
}