<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$page_title = 'Customers';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/flash.php';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("UPDATE customers SET deleted_at = NOW() WHERE id = ?");
        $stmt->execute([$id]);
        flash('success', 'Customer moved to Recycle Bin. You can restore it from there.');
    } catch (PDOException $e) {
        flash('error', 'Could not delete customer: ' . $e->getMessage());
    }
    header('Location: customers.php');
    exit;
}

// Search
$search = trim($_GET['q'] ?? '');
$customers = [];

if ($search !== '') {
    $like = '%' . $search . '%';
    $stmt = $pdo->prepare("SELECT * FROM customers WHERE deleted_at IS NULL AND (customer_name LIKE ? OR phone LIKE ?) ORDER BY customer_name ASC LIMIT 50");
    $stmt->execute([$like, $like]);
    $customers = $stmt->fetchAll();
} else {
    $customers = $pdo->query("SELECT * FROM customers WHERE deleted_at IS NULL ORDER BY id DESC")->fetchAll();
}

// Auto-jump: if search returned exactly 1 result, redirect to it
if ($search !== '' && count($customers) === 1) {
    header('Location: customer-view.php?id=' . (int)$customers[0]['id']);
    exit;
}

require_once __DIR__ . '/includes/header.php';
?>

<header class="leo-page-header">
    <div class="leo-page-header-left">
        <a href="index.php" class="leo-back-btn"><i class="fas fa-chevron-left"></i></a>
        <span class="leo-page-header-title">Customers</span>
    </div>
    <div class="leo-page-header-actions">
        <a href="recycle-bin.php" class="leo-save-btn"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;background:#FEF3C7;color:#92400E;margin-right:0.4rem;">
            <i class="fas fa-recycle"></i> BIN
        </a>
        <a href="customer-guide.php" class="leo-save-btn"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;background:#FEF3C7;color:#92400E;margin-right:0.4rem;">
            <i class="fas fa-circle-question"></i> GUIDE
        </a>
        <a href="customer-add.php" class="leo-save-btn"
           style="text-decoration:none;display:inline-flex;align-items:center;gap:0.4rem;">
            <i class="fas fa-plus"></i> ADD
        </a>
    </div>
</header>

<!-- Search bar -->
<div style="margin:0.85rem 0.85rem 0;">
    <form method="get" action="customers.php" style="display:flex;gap:0.5rem;align-items:center;">
        <div style="position:relative;flex:1;">
            <i class="fas fa-search" style="position:absolute;left:0.9rem;top:50%;transform:translateY(-50%);color:#94A3B8;font-size:0.85rem;pointer-events:none;"></i>
            <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
                   placeholder="Search by name or phone..."
                   autofocus
                   style="width:100%;padding:0.7rem 2.4rem 0.7rem 2.4rem;border:1px solid #E2E8F0;border-radius:10px;font-size:0.9rem;background:#fff;color:#1E293B;outline:none;">
            <?php if ($search !== ''): ?>
                <a href="customers.php"
                   style="position:absolute;right:0.7rem;top:50%;transform:translateY(-50%);color:#94A3B8;font-size:0.9rem;text-decoration:none;"
                   title="Clear search">
                    <i class="fas fa-times-circle"></i>
                </a>
            <?php endif; ?>
        </div>
        <button type="submit"
                style="padding:0.7rem 1.1rem;border:none;border-radius:10px;font-size:0.85rem;font-weight:600;background:var(--leo-primary);color:#fff;cursor:pointer;display:inline-flex;align-items:center;gap:0.4rem;">
            <i class="fas fa-search"></i> <span class="search-btn-text">Search</span>
        </button>
    </form>
    <?php if ($search !== ''): ?>
        <div style="margin-top:0.5rem;font-size:0.82rem;color:var(--leo-muted);">
            Showing <?= count($customers) ?> result<?= count($customers) === 1 ? '' : 's' ?> for "<strong><?= htmlspecialchars($search) ?></strong>"
        </div>
    <?php endif; ?>
</div>

<div class="leo-form-card" style="margin:0.85rem;padding:0;overflow:hidden;">
    <style>
        .cust-table { width:100%; border-collapse:collapse; }
        .cust-table thead th {
            text-align:left; padding:0.9rem 1rem; font-size:0.8rem;
            text-transform:uppercase; color:var(--leo-primary);
            letter-spacing:0.04em; background:var(--leo-blue-soft);
        }
        .cust-table tbody tr { border-top:1px solid #EEF2F7; }

        @media (max-width: 640px) {
            .cust-table thead { display:none; }
            .cust-table, .cust-table tbody, .cust-table tr, .cust-table td {
                display:block; width:100%;
            }
            .cust-table tr {
                padding:0.9rem 1rem;
                border-top:1px solid #EEF2F7;
            }
            .cust-table td {
                padding:0.25rem 0 !important;
                border:none !important;
            }
            .cust-table td[data-label]::before {
                content: attr(data-label) ": ";
                font-weight:700;
                color:var(--leo-primary);
                font-size:0.78rem;
                text-transform:uppercase;
                margin-right:0.4rem;
            }
            .cust-table td.cust-actions {
                text-align:left !important;
                margin-top:0.6rem;
                white-space:normal !important;
            }
            .cust-table td.cust-actions a {
                margin-bottom:0.35rem;
            }
            .search-btn-text { display:none; }
        }
    </style>

    <table class="cust-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Due</th>
                <th style="text-align:right;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($customers) > 0): ?>
                <?php foreach ($customers as $i => $c): ?>
                    <tr>
                        <td data-label="#" style="padding:1rem;font-size:0.9rem;color:var(--leo-muted);"><?= $i + 1 ?></td>
                        <td data-label="Name" style="padding:1rem;font-size:0.95rem;font-weight:600;color:#1E293B;">
                            <a href="customer-view.php?id=<?= (int)$c['id'] ?>" style="color:#1E293B;text-decoration:none;">
                                <?= htmlspecialchars($c['customer_name']) ?>
                            </a>
                        </td>
                        <td data-label="Phone" style="padding:1rem;font-size:0.9rem;color:#475569;">
                            <?= htmlspecialchars($c['phone'] ?? '—') ?>
                        </td>
                        <td data-label="Due" style="padding:1rem;">
                            <span style="display:inline-block;padding:0.25rem 0.7rem;border-radius:999px;font-size:0.72rem;font-weight:700;background:<?= ((float)($c['due'] ?? 0) > 0) ? '#FEE2E2;color:#991B1B;border:1px solid #FCA5A5' : '#DCFCE7;color:#166534;border:1px solid #86EFAC' ?>;">
                                <?= number_format((float)($c['due'] ?? 0), 2) ?>
                            </span>
                        </td>
                        <td class="cust-actions" style="padding:1rem;text-align:right;white-space:nowrap;">
                            <a href="customer-view.php?id=<?= (int)$c['id'] ?>"
                               style="display:inline-flex;align-items:center;gap:0.35rem;padding:0.45rem 0.7rem;border-radius:8px;font-size:0.78rem;font-weight:600;background:#E0F2FE;color:#0369A1;text-decoration:none;margin-right:0.3rem;">
                                <i class="fas fa-eye"></i> View
                            </a>
                            <a href="customer-edit.php?id=<?= (int)$c['id'] ?>"
                               style="display:inline-flex;align-items:center;gap:0.35rem;padding:0.45rem 0.7rem;border-radius:8px;font-size:0.78rem;font-weight:600;background:var(--leo-blue-soft);color:var(--leo-primary);text-decoration:none;margin-right:0.3rem;">
                                <i class="fas fa-pen"></i> Edit
                            </a>
                            <a href="customers.php?delete=<?= (int)$c['id'] ?>"
                               data-confirm="Move '<?= htmlspecialchars($c['customer_name'], ENT_QUOTES) ?>' to the Recycle Bin? You can restore it later."
                               data-confirm-ok="Yes, move to bin"
                               data-confirm-cancel="Cancel"
                               style="display:inline-flex;align-items:center;gap:0.35rem;padding:0.45rem 0.7rem;border-radius:8px;font-size:0.78rem;font-weight:600;background:#FEE2E2;color:#991B1B;text-decoration:none;">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align:center;padding:2.5rem 1rem;color:var(--leo-muted);font-size:0.9rem;">
                        <i class="fas fa-users" style="font-size:1.8rem;display:block;margin-bottom:0.6rem;opacity:0.5;"></i>
                        <?php if ($search !== ''): ?>
                            No customers match "<strong><?= htmlspecialchars($search) ?></strong>".
                            <a href="customers.php" style="color:var(--leo-primary);font-weight:600;">Clear search</a>
                        <?php else: ?>
                            No customers yet. Click <strong>ADD</strong> to create one.
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>